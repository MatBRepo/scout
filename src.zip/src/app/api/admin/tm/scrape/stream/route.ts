// app/api/admin/tm/scrape/stream/route.ts
import type { NextRequest } from "next/server"
import * as cheerio from "cheerio"
import { createClient } from "@supabase/supabase-js"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"
export const revalidate = 0

export async function HEAD() {
  return new Response(null, { status: 200 })
}

type SseEvent = {
  phase?: "init" | "fetch" | "parse" | "save" | "done" | "error"
  message?: string
  progress?: number // 0..1
  counts?: { clubs?: number; players?: number; skipped?: number }
  done?: boolean
  error?: string
}

const BASE = "https://www.transfermarkt.com"
const MAX_FETCH_RETRIES = 4
const BASE_DELAY_MS = 1200   // base backoff
const JITTER_MS = 800        // added randomness
const BETWEEN_CLUB_MS = 1300 // polite pause between clubs
const HEADERS: Record<string, string> = {
  // Polite, browser-like headers (help reduce 403s)
  "User-Agent":
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36",
  "Accept":
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
  "Accept-Language": "en-US,en;q=0.9",
  "Referer": "https://www.transfermarkt.com/",
  "Cache-Control": "no-cache",
  "Pragma": "no-cache",
}

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.SUPABASE_SERVICE_ROLE_KEY! // service role (bypasses RLS on server)
)

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url)
  const path = searchParams.get("path") // e.g. /.../wettbewerb/PL34
  const season = (searchParams.get("season") || "").trim()

  if (!path) return Response.json({ error: "Missing ?path=" }, { status: 400 })
  if (!season) return Response.json({ error: "Missing ?season=" }, { status: 400 })

  const competition_code = path.match(/\/wettbewerb\/([^/?#]+)/i)?.[1] ?? null

  const encoder = new TextEncoder()

  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      const send = (payload: SseEvent) =>
        controller.enqueue(encoder.encode(`data: ${JSON.stringify(payload)}\n\n`))

      const close = () => controller.close()

      ;(async () => {
        try {
          send({ phase: "init", message: "Starting…", progress: 0 })

          // 1) Fetch competition page (with season)
          const compUrl = withSearch(new URL(path, BASE), { saison_id: season })
          send({ phase: "fetch", message: `Fetching competition: ${compUrl}`, progress: 0.02 })
          let html = await fetchHtmlWithRetry(compUrl.toString())

          // Try plus view if no club links
          let clubs = extractClubKaderLinks(html, season)
          if (clubs.length === 0) {
            const plusUrl = addPlus(compUrl)
            send({ phase: "fetch", message: `Retrying with plus view: ${plusUrl}`, progress: 0.05 })
            html = await fetchHtmlWithRetry(plusUrl.toString())
            clubs = extractClubKaderLinks(html, season)
          }

          if (clubs.length === 0) {
            throw new Error("No clubs found on competition page")
          }

          const now = new Date().toISOString()
          send({
            phase: "parse",
            message: `Found ${clubs.length} clubs`,
            progress: 0.07,
            counts: { clubs: clubs.length, players: 0, skipped: 0 },
          })

          // Upsert basic club rows early so "Scraped Data" shows something even if players fail
          if (competition_code) {
            const toUpsert = clubs.map(c => ({
              competition_code,
              season_id: Number(season),
              tm_club_id: c.id,
              name: c.name,
              profile_path: c.profilePath,
              kader_path: c.kaderPath,
              scraped_at: now,
            }))
            await supabase.from("tm_clubs").upsert(toUpsert as any, { onConflict: "season_id,tm_club_id" })
          }

          let doneClubs = 0
          let skippedClubs = 0
          let totalPlayers = 0

          for (const club of clubs) {
            // polite pause to reduce 403s
            await sleep(BETWEEN_CLUB_MS + Math.floor(Math.random() * 700))

            const baseProg = 0.07 + (0.90 - 0.07) * (doneClubs) / clubs.length
            send({
              phase: "fetch",
              message: `Fetching roster: ${new URL(club.kaderPath, BASE)}`,
              progress: baseProg,
              counts: { clubs: doneClubs, players: totalPlayers, skipped: skippedClubs },
            })

            try {
              const rosterHtml = await fetchHtmlWithRetry(new URL(club.kaderPath, BASE).toString())
              const players = parseRosterPlayers(rosterHtml)

              if (players.length) {
                // tm_players
                const playerMaster = players.map(p => ({
                  tm_player_id: p.id,
                  name: p.name,
                  profile_path: p.profilePath,
                  photo_url: p.photoUrl,
                }))
                await supabase.from("tm_players").upsert(playerMaster as any, { onConflict: "tm_player_id" })

                // tm_squad_players
                const squad = players.map(p => ({
                  season_id: Number(season),
                  tm_club_id: club.id,
                  tm_player_id: p.id,
                  name: p.name,
                  position: p.position ?? null,
                  nationality: p.nationalities,
                  dob: p.dob ?? null,
                  height_cm: p.heightCm ?? null,
                  foot: p.foot ?? null,
                  joined: p.joined ?? null,
                  contract_end: p.contractEnd ?? null,
                  market_value_eur: p.marketValueEur ?? null,
                  profile_path: p.profilePath,
                  photo_url: p.photoUrl,
                }))
                await supabase.from("tm_squad_players").upsert(squad as any, {
                  onConflict: "season_id,tm_club_id,tm_player_id",
                })
              }

              totalPlayers += players.length
              doneClubs += 1

              const endProg = 0.07 + (0.90 - 0.07) * (doneClubs) / clubs.length
              send({
                phase: "parse",
                message: `Parsed ${players.length} players · ${club.name}`,
                progress: endProg,
                counts: { clubs: doneClubs, players: totalPlayers, skipped: skippedClubs },
              })
            } catch (err: any) {
              // keep going on a single-club failure
              skippedClubs += 1
              doneClubs += 1
              const endProg = 0.07 + (0.90 - 0.07) * (doneClubs) / clubs.length
              const msg = (err?.message || String(err)).slice(0, 180)
              send({
                phase: "error",
                message: `Skipping ${club.name}: ${msg}`,
                progress: endProg,
                counts: { clubs: doneClubs, players: totalPlayers, skipped: skippedClubs },
              })
            }
          }

          send({
            phase: "done",
            message: `Finished: ${doneClubs} clubs / ${totalPlayers} players · skipped: ${skippedClubs}`,
            progress: 1,
            counts: { clubs: doneClubs, players: totalPlayers, skipped: skippedClubs },
            done: true,
          })
          close()
        } catch (err: any) {
          send({
            phase: "error",
            message: err?.message || String(err),
            error: err?.message || String(err),
            progress: 1,
            done: true,
          })
          close()
        }
      })()
    },
  })

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  })
}

/* ---------------- Helpers ---------------- */

function withSearch(u: URL, params: Record<string, string>) {
  const url = new URL(u.toString())
  for (const [k, v] of Object.entries(params)) url.searchParams.set(k, v)
  return url
}

function addPlus(u: URL) {
  const url = new URL(u.toString())
  if (!/\/plus\/?$/i.test(url.pathname)) {
    url.pathname = url.pathname.replace(/\/?$/, "/plus/1")
  }
  return url
}

async function fetchHtmlWithRetry(url: string, attempts = MAX_FETCH_RETRIES): Promise<string> {
  let lastErr: any = null
  for (let i = 0; i < attempts; i++) {
    try {
      const res = await fetch(url, { headers: HEADERS, cache: "no-store" })
      if (!res.ok) {
        const txt = await res.text().catch(() => "")
        // Throw for retry on 403/429; throw immediately on other 4xx/5xx
        if (res.status === 403 || res.status === 429) {
          throw new Error(`HTTP ${res.status} for ${url} — ${txt.slice(0, 120)}`)
        } else {
          throw new Error(`HTTP ${res.status} for ${url} — ${txt.slice(0, 120)}`)
        }
      }
      return res.text()
    } catch (err) {
      lastErr = err
      // backoff with jitter
      const wait = BASE_DELAY_MS * Math.pow(1.7, i) + Math.floor(Math.random() * JITTER_MS)
      await sleep(wait)
    }
  }
  throw lastErr || new Error(`Failed to fetch after ${attempts} attempts: ${url}`)
}

function extractClubKaderLinks(html: string, season: string) {
  const $ = cheerio.load(html)
  const clubs: Array<{ id: number; name: string; profilePath: string; kaderPath: string }> = []

  // direct “kader” links
  $("a[href*='/kader/verein/']").each((_, el) => {
    const href = $(el).attr("href") || ""
    const name = $(el).text().trim()
    const id = Number(href.match(/\/verein\/(\d+)/)?.[1] || NaN)
    if (!id) return
    const profilePath = href
    const kp = ensureSeasonInKaderPath(href, season)
    clubs.push({ id, name, profilePath, kaderPath: kp })
  })

  // fallback “startseite/verein”
  if (clubs.length === 0) {
    $("a[href*='/startseite/verein/']").each((_, el) => {
      const href = $(el).attr("href") || ""
      const name = $(el).text().trim()
      const id = Number(href.match(/\/verein\/(\d+)/)?.[1] || NaN)
      if (!id) return
      const profilePath = href
      const kaderPath = ensureSeasonInKaderPath(
        href.replace("/startseite/verein/", "/kader/verein/"),
        season
      )
      clubs.push({ id, name, profilePath, kaderPath })
    })
  }

  const seen = new Set<number>()
  return clubs.filter(c => (seen.has(c.id) ? false : (seen.add(c.id), true)))
}

function ensureSeasonInKaderPath(href: string, season: string) {
  let p = href
  if (!/\/kader\/verein\//.test(p)) {
    p = p.replace("/startseite/verein/", "/kader/verein/")
  }
  if (!/\/saison_id\//.test(p)) {
    p = p.replace(/\/kader\/verein\/(\d+)/, `/kader/verein/$1/saison_id/${season}`)
  } else {
    p = p.replace(/(\/saison_id\/)\d+/, `$1${season}`)
  }
  if (!/\/plus\/1/.test(p)) {
    p = p.replace(/\/?$/, "/plus/1")
  }
  return p
}

type ParsedPlayer = {
  id: number
  name: string
  position?: string
  nationalities: string[]
  dob?: string | null
  heightCm?: number | null
  foot?: string | null
  joined?: string | null
  contractEnd?: string | null
  marketValueEur?: number | null
  profilePath: string
  photoUrl?: string | null
}

function parseRosterPlayers(html: string): ParsedPlayer[] {
  const $ = cheerio.load(html)
  const players: ParsedPlayer[] = []

  $("table.items > tbody > tr").each((_, tr) => {
    const $tr = $(tr)
    const tds = $tr.find("td")
    if (tds.length < 5) return

    const posTd = $(tds.get(1))
    const nameA = posTd.find(".hauptlink a[href*='/profil/spieler/']").first()
    const name = nameA.text().trim()
    const profilePath = nameA.attr("href") || ""
    const id = Number(profilePath.match(/\/spieler\/(\d+)/)?.[1] || NaN)
    if (!name || !id) return

    const position = posTd.find("table.inline-table tr").eq(1).find("td").text().trim() || undefined

    // prefer data-src; fall back to src; make absolute if needed
    const img = posTd.find("img").first()
    let photo = img.attr("data-src") || img.attr("src") || null
    if (photo && photo.startsWith("/")) photo = new URL(photo, BASE).toString()

    const dob = parseGermanDate($(tds.get(2)).text().trim())

    const nats: string[] = []
    $(tds.get(3)).find("img[alt]").each((_, flag) => {
      const alt = $(flag).attr("alt")?.trim()
      if (alt) nats.push(alt)
    })

    const heightCm = parseHeightCm($(tds.get(4)).text().trim())
    const foot = ($(tds.get(5)).text().trim() || null) || null
    const joined = parseGermanDate($(tds.get(6)).text().trim())
    const contractEnd = parseGermanDate($(tds.get(8)).text().trim())
    const marketValueEur = parseMarketValue($(tds.get(9)).text().trim())

    players.push({
      id,
      name,
      position,
      nationalities: nats,
      dob,
      heightCm,
      foot,
      joined,
      contractEnd,
      marketValueEur,
      profilePath,
      photoUrl: photo,
    })
  })

  return players
}

function parseGermanDate(s: string): string | null {
  const m = s.match(/(\d{2})\.(\d{2})\.(\d{4})/)
  if (!m) return null
  const [_, dd, mm, yyyy] = m
  return `${yyyy}-${mm}-${dd}`
}

function parseHeightCm(s: string): number | null {
  const m = s.replace(/\s/g, "").match(/(\d)[,.](\d{2})m/i)
  if (!m) return null
  const cm = Number(m[1]) * 100 + Number(m[2])
  return Number.isFinite(cm) ? cm : null
}

function parseMarketValue(s: string): number | null {
  const m = s.replace(/\s/g, "").match(/€([\d.,]+)([mk])?/i)
  if (!m) return null
  const num = parseFloat(m[1].replace(",", "."))
  const unit = (m[2] || "").toLowerCase()
  if (unit === "m") return Math.round(num * 1_000_000)
  if (unit === "k") return Math.round(num * 1_000)
  return Math.round(num)
}

function sleep(ms: number) {
  return new Promise((r) => setTimeout(r, ms))
}
