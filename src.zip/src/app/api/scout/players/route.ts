import { NextResponse } from "next/server"
import { createClient } from "@/lib/supabase/server"

export async function POST(req: Request) {
  const supabase = createClient()
  const { data: { user } } = await supabase.auth.getUser()
  if (!user) return NextResponse.json({ error: "not_authenticated" }, { status: 401 })

  const payload = await req.json()
  const {
    full_name, date_of_birth, main_position, current_club_name,
    transfermarkt_url, opinion, image_url, image_path
  } = payload

  const { error } = await supabase.from("scout_player_entries").insert({
    scout_id: user.id,
    full_name,
    date_of_birth,
    main_position: main_position || null,
    current_club_name: current_club_name || null,
    transfermarkt_url: transfermarkt_url || null,
    opinion: opinion || null,
    image_url: image_url || null,
    image_path: image_path || null,
    status: "submitted",
  })

  if (error) return NextResponse.json({ error: error.message }, { status: 400 })
  return NextResponse.json({ ok: true })
}
