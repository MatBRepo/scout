"use client"

import Link from "next/link"
import { useEffect, useMemo, useState } from "react"
import type { Row } from "./page"
import { createClient } from "@/lib/supabase/browser"
import { toast } from "sonner"

import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"

import { ExternalLink, Users, PlusCircle, Loader2, CheckCircle2 } from "lucide-react"

type Session = { id: string; title: string | null; match_date: string }

export default function MyPlayersClient({ rows }: { rows: Row[] }) {
  const supabase = createClient()
  const items = useMemo(() => rows ?? [], [rows])

  // Sessions (loaded once for current scout)
  const [sessions, setSessions] = useState<Session[]>([])
  const [loadingSessions, setLoadingSessions] = useState(true)

  // For each player: which session ids already contain them
  const [existingByPlayer, setExistingByPlayer] = useState<Record<string, Set<string>>>({})

  // Per-player session selection and loading state for "add"
  const [selectedByPlayer, setSelectedByPlayer] = useState<Record<string, string>>({})
  const [addingByPlayer, setAddingByPlayer] = useState<Record<string, boolean>>({})

  // Load sessions
  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        const { data: { user } } = await supabase.auth.getUser()
        if (!user) return
        const { data, error } = await supabase
          .from("observation_sessions")
          .select("id, title, match_date")
          .eq("scout_id", user.id)
          .order("match_date", { ascending: false })
        if (error) throw error
        if (mounted) setSessions(data || [])
      } catch (e: any) {
        console.error("Load sessions error:", e)
        toast.error(e?.message || "Failed to load observation sessions")
      } finally {
        if (mounted) setLoadingSessions(false)
      }
    })()
    return () => { mounted = false }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Load which players are already in which sessions (for this scout)
  useEffect(() => {
    let mounted = true
    ;(async () => {
      try {
        if (!sessions.length || !items.length) return
        const sessionIds = sessions.map(s => s.id)
        const playerIds = items.map(i => i.id)

        // RLS must allow: see policies from previous message.
        const { data, error } = await supabase
          .from("observation_players")
          .select("observation_id, player_id")
          .in("observation_id", sessionIds)
          .in("player_id", playerIds)

        if (error) throw error

        const map: Record<string, Set<string>> = {}
        for (const row of data || []) {
          const pid = row.player_id as string
          const oid = row.observation_id as string
          if (!map[pid]) map[pid] = new Set()
          map[pid].add(oid)
        }
        if (mounted) setExistingByPlayer(map)
      } catch (e: any) {
        console.error("Load existing observation_players error:", e)
        // don’t toast spam here; fail silently
      }
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessions, items.length])

  function setSelectedSession(playerId: string, sessionId: string) {
    setSelectedByPlayer(prev => ({ ...prev, [playerId]: sessionId }))
  }

  async function addToObservation(playerId: string) {
    const sessionId = selectedByPlayer[playerId]
    if (!sessionId) {
      toast.info("Choose observation session first")
      return
    }

    // if already in selected session, just inform
    const alreadySet = existingByPlayer[playerId]?.has(sessionId)
    if (alreadySet) {
      toast.info("Player is already in this observation")
      return
    }

    setAddingByPlayer(prev => ({ ...prev, [playerId]: true }))
    try {
      const { error } = await supabase.from("observation_players").insert({
        observation_id: sessionId,
        player_id: playerId,
        minutes_watched: null,
        rating: null,
        notes: null,
      })
      if (error) throw error

      // reflect immediately
      setExistingByPlayer(prev => {
        const next = { ...prev }
        const set = new Set(next[playerId] ?? [])
        set.add(sessionId)
        next[playerId] = set
        return next
      })

      toast.success("Player added to observation")
    } catch (e: any) {
      console.error("Add to observation error:", e)
      toast.error(e?.message || "Could not add player to observation")
    } finally {
      setAddingByPlayer(prev => ({ ...prev, [playerId]: false }))
    }
  }

  if (!items.length) {
    return (
      <div className="space-y-4 w-full">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-semibold">My Players</h1>
          <div className="text-sm text-muted-foreground flex items-center gap-2">
            <Users className="h-4 w-4" /> 0 players
          </div>
        </div>
        <Separator />
        <Card className="p-6 rounded-2xl text-sm text-muted-foreground">
          No players yet. Add one from <span className="font-medium">Discover</span> or via <span className="font-medium">Add Player</span>.
        </Card>
      </div>
    )
  }

  return (
    <div className="space-y-4 w-full">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">My Players</h1>
        <div className="text-sm text-muted-foreground flex items-center gap-2">
          <Users className="h-4 w-4" /> {items.length} player{items.length === 1 ? "" : "s"}
        </div>
      </div>

      <Separator />

      {/* Mobile: horizontal rail with snap */}
      <div className="md:hidden">
        <div className="overflow-x-auto pb-3" role="region" aria-label="My Players horizontal list">
          <div className="flex gap-4 snap-x snap-mandatory">
            {items.map((p) => (
              <PlayerCard
                key={p.id}
                p={p}
                sessions={sessions}
                loadingSessions={loadingSessions}
                existingSessionIds={existingByPlayer[p.id]}
                selectedSession={selectedByPlayer[p.id] || ""}
                onSelectSession={(id) => setSelectedSession(p.id, id)}
                onAddToObservation={() => addToObservation(p.id)}
                adding={!!addingByPlayer[p.id]}
                className="snap-start min-w-[85vw] max-w-[85vw]"
              />
            ))}
          </div>
        </div>
      </div>

      {/* Desktop: responsive grid */}
      <div className="hidden md:block">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {items.map((p) => (
            <PlayerCard
              key={p.id}
              p={p}
              sessions={sessions}
              loadingSessions={loadingSessions}
              existingSessionIds={existingByPlayer[p.id]}
              selectedSession={selectedByPlayer[p.id] || ""}
              onSelectSession={(id) => setSelectedSession(p.id, id)}
              onAddToObservation={() => addToObservation(p.id)}
              adding={!!addingByPlayer[p.id]}
            />
          ))}
        </div>
      </div>
    </div>
  )
}

function PlayerCard({
  p,
  sessions,
  loadingSessions,
  existingSessionIds,
  selectedSession,
  onSelectSession,
  onAddToObservation,
  adding = false,
  className = "",
}: {
  p: Row
  sessions: Session[]
  loadingSessions: boolean
  existingSessionIds?: Set<string>
  selectedSession: string
  onSelectSession: (id: string) => void
  onAddToObservation: () => void
  adding?: boolean
  className?: string
}) {
  const existsInAny = !!existingSessionIds && existingSessionIds.size > 0
  const existsInSelected = !!(selectedSession && existingSessionIds?.has(selectedSession))

  return (
    <Card className={`rounded-2xl border bg-card/50 hover:shadow-sm transition ${className}`}>
      <div className="p-4">
        {/* Header: avatar + meta */}
        <div className="flex items-center gap-3">
          <PlayerAvatar src={p.image_url} alt={p.full_name} />
          <div className="min-w-0">
            <div className="font-semibold truncate">{p.full_name}</div>
            <div className="text-xs text-muted-foreground truncate">
              {p.main_position ? `Pos: ${p.main_position}` : "—"}
              {p.current_club_name ? ` · ${p.current_club_name}` : ""}
              {p.current_club_country ? ` (${p.current_club_country})` : ""}
            </div>
            {existsInAny && (
              <div className="mt-1 inline-flex items-center gap-1 text-[11px] text-emerald-700">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Already in {existingSessionIds!.size} observation{existingSessionIds!.size > 1 ? "s" : ""}
              </div>
            )}
          </div>
        </div>

        {/* Pills */}
        <div className="mt-3 flex flex-wrap gap-2">
          {p.main_position && <Badge variant="secondary">{p.main_position}</Badge>}
          {p.current_club_name && <Badge variant="outline">{p.current_club_name}</Badge>}
        </div>

        {/* Primary actions */}
        <div className="mt-4 grid grid-cols-1 sm:grid-cols-2 gap-2">
          <Button asChild size="sm" className="w-full">
            <Link href={`/scout/players/${p.id}`}>Details</Link>
          </Button>

          {p.transfermarkt_url && (
            <Button asChild size="sm" variant="outline" className="w-full">
              <a href={p.transfermarkt_url} target="_blank" rel="noreferrer">
                Transfermarkt <ExternalLink className="ml-1 h-3 w-3" />
              </a>
            </Button>
          )}
        </div>

        {/* Add to observation (Select + button UNDER it) */}
        <div className="mt-3 flex flex-col gap-2">
          <Select value={selectedSession} onValueChange={onSelectSession} disabled={loadingSessions || adding}>
            <SelectTrigger className="h-9 w-full">
              <SelectValue placeholder={loadingSessions ? "Loading sessions…" : "Choose observation session…"} />
            </SelectTrigger>
            <SelectContent>
              {sessions.length === 0 ? (
                <div className="px-2 py-1.5 text-xs text-muted-foreground">No sessions found</div>
              ) : (
                sessions.map(s => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.match_date} {s.title ? `· ${s.title}` : ""}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>

          {existsInSelected && (
            <div className="text-[12px] text-emerald-700 inline-flex items-center gap-1">
              <CheckCircle2 className="h-3.5 w-3.5" />
              Already in this observation
            </div>
          )}

          <Button
            size="sm"
            className="w-full"
            onClick={onAddToObservation}
            disabled={adding || existsInSelected || !selectedSession}
          >
            {adding ? (
              <>
                <Loader2 className="h-4 w-4 mr-1 animate-spin" /> Adding…
              </>
            ) : existsInSelected ? (
              "Already added"
            ) : (
              <>
                <PlusCircle className="h-4 w-4 mr-1" /> Add to observation
              </>
            )}
          </Button>
        </div>
      </div>
    </Card>
  )
}

function PlayerAvatar({ src, alt }: { src: string | null; alt: string }) {
  if (!src) {
    return (
      <div className="h-16 w-16 rounded-md bg-muted grid place-items-center text-[10px] text-muted-foreground shrink-0">
        No photo
      </div>
    )
  }
  return (
    <img
      src={src}
      alt={alt}
      className="h-16 w-16 rounded-md object-cover border shrink-0"
      loading="lazy"
      decoding="async"
    />
  )
}
