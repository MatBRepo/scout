"use client"

import React, { useState } from "react"
import Link from "next/link"
import { createClient } from "@/lib/supabase/browser"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  ChevronDown,
  ChevronRight,
  CalendarDays,
  Users,
  Loader2,
  NotebookText,
  Plus,
} from "lucide-react"

// shadcn/ui Sheet (offcanvas)
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
  SheetClose,
} from "@/components/ui/sheet"

// 👉 We reuse your full editor (client) inside the offcanvas
// Path: src/app/scout/observations/[id]/view.client.tsx
import ObservationEditor from "../[id]/view.client"

type Row = {
  id: string
  title: string | null
  match_date: string | null // YYYY-MM-DD
  competition: string | null
  opponent: string | null
  players_count: number
}

type Details = {
  notes: string | null
  players: {
    row_id: string
    type: "player" | "entry"
    id: string
    full_name: string
    image_url: string | null
    transfermarkt_url?: string | null
    minutes_watched: number | null
    rating: number | null
    notes: string | null
  }[]
  title: string | null
  match_date: string | null
  competition: string | null
  opponent: string | null
}

type EditorPayload = {
  session: any
  rows: any[]
}

type Props = { initialRows: Row[] }

export default function ObservationsTable({ initialRows }: Props) {
  const [rows] = useState<Row[]>(initialRows)

  // Inline expand (keep quick view if you like)
  const [open, setOpen] = useState<Set<string>>(new Set())
  const [loading, setLoading] = useState<Record<string, boolean>>({})
  const [details, setDetails] = useState<Record<string, Details | null>>({})

  // Offcanvas full editor state
  const [editorOpen, setEditorOpen] = useState(false)
  const [editorId, setEditorId] = useState<string | null>(null)
  const [editorBusy, setEditorBusy] = useState(false)
  const [editorData, setEditorData] = useState<EditorPayload | null>(null)

  const supabase = createClient()

  // Toggle inline details (optional, can be removed if you only want offcanvas)
  const toggle = async (id: string) => {
    setOpen(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
    if (!details[id]) {
      await loadDetails(id, (data) => {
        setDetails(d => ({ ...d, [id]: data }))
      }, (is) => setLoading(s => ({ ...s, [id]: is })))
    }
  }

  // Open Editor in offcanvas
  const openEditor = async (id: string) => {
    setEditorId(id)
    setEditorOpen(true)
    setEditorBusy(true)
    setEditorData(null)
    try {
      // Fetch full session + rows using Supabase (browser)
      const [obs, list] = await Promise.all([
        supabase
          .from("observation_sessions")
          .select("*")
          .eq("id", id)
          .maybeSingle(),
        supabase
          .from("observation_players")
          .select(`
            id,
            observation_id,
            player_id,
            player_entry_id,
            minutes_watched,
            rating,
            notes,
            players ( id, full_name, image_url, transfermarkt_url ),
            scout_player_entries ( id, full_name, image_url, transfermarkt_url )
          `)
          .eq("observation_id", id)
          .order("created_at", { ascending: false }),
      ])

      setEditorData({
        session: obs.data,
        rows: list.data ?? [],
      })
    } finally {
      setEditorBusy(false)
    }
  }

  // Shared loader for inline details (quick view)
  const loadDetails = async (
    id: string,
    setData: (d: Details) => void,
    setBusy: (b: boolean) => void | React.Dispatch<React.SetStateAction<boolean>>
  ) => {
    try {
      typeof setBusy === "function" ? setBusy(true) : null

      const [obs, list] = await Promise.all([
        supabase
          .from("observation_sessions")
          .select("id, title, match_date, competition, opponent, notes")
          .eq("id", id)
          .maybeSingle(),
        supabase
          .from("observation_players")
          .select(`
            id,
            minutes_watched,
            rating,
            notes,
            player_id,
            player_entry_id,
            players ( id, full_name, image_url, transfermarkt_url ),
            scout_player_entries ( id, full_name, image_url, transfermarkt_url )
          `)
          .eq("observation_id", id)
          .order("created_at", { ascending: false }),
      ])

      const players =
        (list.data ?? []).map((r: any) => {
          const p = r.players ?? r.scout_player_entries
          const type: "player" | "entry" = r.player_id ? "player" : "entry"
          return {
            row_id: r.id as string,
            type,
            id: (p?.id ?? "") as string,
            full_name: (p?.full_name ?? "(unknown)") as string,
            image_url: (p?.image_url ?? null) as string | null,
            transfermarkt_url: (p?.transfermarkt_url ?? null) as string | null,
            minutes_watched: (r.minutes_watched ?? null) as number | null,
            rating: (r.rating ?? null) as number | null,
            notes: (r.notes ?? null) as string | null,
          }
        }) ?? []

      const data: Details = {
        notes: obs.data?.notes ?? null,
        players,
        title: obs.data?.title ?? null,
        match_date: obs.data?.match_date ?? null,
        competition: obs.data?.competition ?? null,
        opponent: obs.data?.opponent ?? null,
      }

      setData(data)
    } finally {
      typeof setBusy === "function" ? setBusy(false) : null
    }
  }

  const formatDate = (d?: string | null) => d ?? "—"

  return (
    <>
      <Card className="overflow-hidden">
        {/* -------- Mobile: stacked cards -------- */}
        <div className="space-y-3 p-3 md:hidden">
          <Card className="border-dashed p-3">
            <div className="flex items-center justify-between gap-2">
              <div className="text-xs text-muted-foreground">
                Create a session for a match you want to observe.
              </div>
              <Button asChild size="sm" className="gap-1.5">
                <Link href="/scout/observations/new">
                  <Plus className="h-4 w-4" />
                  New
                </Link>
              </Button>
            </div>
          </Card>

          {rows.map((r) => {
            const isOpen = open.has(r.id)
            const status = statusOf(r.match_date)
            const det = details[r.id]
            return (
              <Card key={r.id} className="p-3">
                <div className="flex items-start justify-between gap-3">
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="truncate font-medium">
                        {r.title || r.competition || "Observation"}
                      </div>
                      {r.competition && (
                        <Badge variant="secondary" className="text-[11px]">
                          {r.competition}
                        </Badge>
                      )}
                      <StatusBadge status={status} />
                    </div>
                    <div className="mt-1 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1.5">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {formatDate(r.match_date)}
                      </span>
                      <span className="max-w-[60vw] truncate">
                        {r.opponent ? `vs ${r.opponent}` : "—"}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Users className="h-3.5 w-3.5" />
                        {r.players_count}
                      </span>
                    </div>
                  </div>

                  <div className="flex shrink-0 items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className="gap-1"
                      onClick={() => openEditor(r.id)} // 🔥 Full editor in offcanvas
                    >
                      Open <ChevronRight className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="gap-1.5"
                      onClick={() => toggle(r.id)}
                      aria-expanded={isOpen}
                      aria-controls={`obs-${r.id}-panel`}
                    >
                      {isOpen ? (
                        <>
                          Hide <ChevronDown className="h-4 w-4" />
                        </>
                      ) : (
                        <>
                          Details <ChevronRight className="h-4 w-4" />
                        </>
                      )}
                    </Button>
                  </div>
                </div>

                {isOpen && (
                  <div id={`obs-${r.id}-panel`} className="mt-3 space-y-3">
                    {loading[r.id] && (
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Loader2 className="h-4 w-4 animate-spin" />
                        Loading details…
                      </div>
                    )}
                    {!loading[r.id] && det && (
                      <>
                        <Card className="p-3">
                          <div className="mb-1 flex items-center gap-2">
                            <NotebookText className="h-4 w-4 text-muted-foreground" />
                            <div className="text-xs font-medium">Session note</div>
                          </div>
                          {det.notes ? (
                            <p className="whitespace-pre-wrap text-sm leading-relaxed">
                              {det.notes}
                            </p>
                          ) : (
                            <div className="text-xs text-muted-foreground">
                              No note yet.
                              <Button
                                variant="link"
                                className="px-1 text-xs"
                                onClick={() => openEditor(r.id)} // manage -> editor
                              >
                                Add one
                              </Button>
                            </div>
                          )}
                        </Card>
                        <PlayersCard det={det} openEditor={() => openEditor(r.id)} compact />
                      </>
                    )}
                  </div>
                )}
              </Card>
            )
          })}

          {rows.length === 0 && (
            <Card className="p-6 text-center">
              <div className="text-sm font-medium">No observations yet</div>
              <div className="mt-1 text-xs text-muted-foreground">
                Create your first session to start logging players and notes.
              </div>
              <div className="mt-3">
                <Button asChild>
                  <Link href="/scout/observations/new">
                    <Plus className="mr-1 h-4 w-4" />
                    New observation
                  </Link>
                </Button>
              </div>
            </Card>
          )}
        </div>

        {/* -------- Desktop: table -------- */}
        <div className="hidden max-w-full overflow-x-auto md:block">
          <table className="w-full min-w-[880px] text-sm">
            <thead>
              <tr className="bg-muted/40 text-xs text-muted-foreground [&>th]:px-3 [&>th]:py-2">
                <th className="w-10" aria-label="Expand" />
                <th className="text-left">Date</th>
                <th className="min-w-[240px] text-left">Title / Competition</th>
                <th className="text-left">Opponent</th>
                <th className="text-left">Players</th>
                <th className="text-right">Actions</th>
              </tr>
            </thead>
            <tbody>
              {/* quick-create row */}
              <tr className="border-t bg-muted/20">
                <td className="px-3 py-2" />
                <td className="px-3 py-2" colSpan={4}>
                  <div className="flex items-center justify-between">
                    <div className="text-xs text-muted-foreground">
                      Create a session for a match you want to observe.
                    </div>
                  </div>
                </td>
                <td className="px-3 py-2 text-right">
                  <Button asChild size="sm" className="gap-1.5">
                    <Link href="/scout/observations/new">
                      <Plus className="h-4 w-4" />
                      New
                    </Link>
                  </Button>
                </td>
              </tr>

              {rows.map((r) => {
                const isOpen = open.has(r.id)
                const status = statusOf(r.match_date)
                return (
                  <React.Fragment key={r.id}>
                    <tr className="border-t [&>td]:px-3 [&>td]:py-2">
                      <td className="whitespace-nowrap">
                        <button
                          type="button"
                          onClick={() => toggle(r.id)}
                          className="inline-flex h-7 items-center justify-center rounded-md border bg-background px-3 hover:bg-accent hover:text-accent-foreground"
                          aria-label={isOpen ? "Collapse" : "Expand"}
                          aria-expanded={isOpen}
                          aria-controls={`row-${r.id}-details`}
                        >
                          {isOpen ? (
                            <>
                              Hide details <ChevronDown className="ml-1 h-4 w-4" />
                            </>
                          ) : (
                            <>
                              Expand details <ChevronRight className="ml-1 h-4 w-4" />
                            </>
                          )}
                        </button>
                      </td>
                      <td className="whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <CalendarDays className="h-4 w-4 text-muted-foreground" />
                          {formatDate(r.match_date)}
                        </div>
                      </td>
                      <td className="min-w-[220px]">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="max-w-[360px] truncate font-medium">
                            {r.title || r.competition || "Observation"}
                          </span>
                          {r.competition && (
                            <Badge variant="secondary" className="text-[11px]">
                              {r.competition}
                            </Badge>
                          )}
                          <StatusBadge status={status} />
                        </div>
                      </td>
                      <td className="max-w-[260px] truncate whitespace-nowrap">{r.opponent || "—"}</td>
                      <td className="whitespace-nowrap">
                        <div className="inline-flex items-center gap-1.5">
                          <Users className="h-4 w-4 text-muted-foreground" />
                          {r.players_count}
                        </div>
                      </td>
                      <td className="text-right">
                        <Button
                          variant="outline"
                          size="sm"
                          className="gap-1"
                          onClick={() => openEditor(r.id)} // 🔥 Full editor in offcanvas
                        >
                          Open <ChevronRight className="h-4 w-4" />
                        </Button>
                      </td>
                    </tr>

                    {isOpen && (
                      <tr id={`row-${r.id}-details`} className="bg-muted/20">
                        <td colSpan={6} className="px-3 py-3">
                          {loading[r.id] && (
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Loader2 className="h-4 w-4 animate-spin" />
                              Loading details…
                            </div>
                          )}
                          {!loading[r.id] && details[r.id] && (
                            <div className="grid gap-4 sm:grid-cols-2">
                              <Card className="p-3">
                                <div className="mb-1 flex items-center gap-2">
                                  <NotebookText className="h-4 w-4 text-muted-foreground" />
                                  <div className="text-xs font-medium">Session note</div>
                                </div>
                                {details[r.id]!.notes ? (
                                  <p className="whitespace-pre-wrap text-sm leading-relaxed">
                                    {details[r.id]!.notes}
                                  </p>
                                ) : (
                                  <div className="text-xs text-muted-foreground">
                                    No note yet.
                                    <Button
                                      variant="link"
                                      className="px-1 text-xs"
                                      onClick={() => openEditor(r.id)}
                                    >
                                      Add one
                                    </Button>
                                  </div>
                                )}
                              </Card>
                              <PlayersCard det={details[r.id]!} openEditor={() => openEditor(r.id)} />
                            </div>
                          )}
                        </td>
                      </tr>
                    )}
                  </React.Fragment>
                )
              })}

              {rows.length === 0 && (
                <tr className="border-t">
                  <td colSpan={6} className="px-3 py-10 text-center">
                    <div className="mx-auto max-w-md">
                      <div className="text-sm font-medium">No observations yet</div>
                      <div className="mt-1 text-xs text-muted-foreground">
                        Create your first session to start logging players and notes.
                      </div>
                      <div className="mt-3">
                        <Button asChild>
                          <Link href="/scout/observations/new">
                            <Plus className="mr-1 h-4 w-4" />
                            New observation
                          </Link>
                        </Button>
                      </div>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </Card>

      {/* ---------- Offcanvas: FULL EDITOR ---------- */}
      <Sheet open={editorOpen} onOpenChange={setEditorOpen}>
        <SheetContent
          side="right"
          // Full-width on small screens; wide editor on desktop
          className="flex w-full flex-col gap-0 p-0 sm:max-w-full md:max-w-3xl lg:max-w-5xl"
        >
          <SheetHeader className="border-b bg-background/80 p-4 backdrop-blur">
            <SheetTitle className="text-base">
              {editorData?.session?.title ||
                editorData?.session?.competition ||
                "Observation"}
            </SheetTitle>
            <SheetDescription className="text-xs">
              {editorId ? `#${editorId}` : ""}
            </SheetDescription>
          </SheetHeader>

          <div className="flex-1 overflow-y-auto p-4">
            {editorBusy && (
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                Loading editor…
              </div>
            )}

            {!editorBusy && editorData && editorData.session && (
              <ObservationEditor
                // 👇 your full editor dropped right in
                session={editorData.session}
                rows={editorData.rows}
              />
            )}

            {!editorBusy && (!editorData || !editorData.session) && (
              <div className="text-sm text-muted-foreground">
                Could not load this observation.
              </div>
            )}
          </div>

          <div className="border-t p-3 text-right">
            <SheetClose asChild>
              <Button variant="outline">Close</Button>
            </SheetClose>
          </div>
        </SheetContent>
      </Sheet>
    </>
  )
}

/* ---------- helpers ---------- */
function statusOf(dateStr?: string | null): "upcoming" | "past" | "unknown" {
  if (!dateStr) return "unknown"
  const today = new Date().toISOString().slice(0, 10)
  return dateStr >= today ? "upcoming" : "past"
}

function StatusBadge({ status }: { status: "upcoming" | "past" | "unknown" }) {
  if (status === "upcoming") {
    return (
      <Badge variant="secondary" className="gap-1 text-[11px]">
        <svg className="h-3.5 w-3.5" viewBox="0 0 24 24" stroke="currentColor" fill="none" strokeWidth="2">
          <path d="M12 6v6l4 2" />
          <circle cx="12" cy="12" r="10" />
        </svg>
        Upcoming
      </Badge>
    )
  }
  if (status === "past") return <Badge variant="outline">Past</Badge>
  return <Badge variant="outline">Scheduled</Badge>
}

/* ---------- subcomponent for inline quick view ---------- */
function PlayersCard({
  det,
  openEditor,
  compact = false,
}: {
  det: Details
  openEditor: () => void
  compact?: boolean
}) {
  return (
    <Card className="p-3">
      <div className="mb-2 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Users className="h-4 w-4 text-muted-foreground" />
          <div className="text-xs font-medium">Players in this session</div>
        </div>
        <Button size="sm" variant="outline" className="h-7 gap-1" onClick={openEditor}>
          Manage <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {det.players.length ? (
        <div className="flex flex-wrap gap-2">
          {det.players.map((p) => (
            <div
              key={p.row_id}
              className="inline-flex items-center gap-2 rounded-md border bg-background px-2 py-1"
              title={p.full_name}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={p.image_url || "/placeholder.svg"}
                alt={p.full_name}
                className="h-7 w-7 rounded border object-cover"
              />
              <span className={`truncate text-xs ${compact ? "max-w-[55vw]" : "max-w-[220px]"}`}>
                {p.full_name}
              </span>
              <Badge
                variant={p.type === "player" ? "secondary" : "outline"}
                className="text-[10px]"
              >
                {p.type === "player" ? "Player" : "Entry"}
              </Badge>
            </div>
          ))}
        </div>
      ) : (
        <div className="text-xs text-muted-foreground">
          No players yet.
          <Button variant="link" className="px-1 text-xs" onClick={openEditor}>
            Add players
          </Button>
        </div>
      )}
    </Card>
  )
}
