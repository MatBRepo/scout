// src/app/scout/observations/[id]/view.client.tsx
"use client"

import { Fragment, useEffect, useRef, useState } from "react"
import { createClient } from "@/lib/supabase/browser"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { toast } from "sonner"
import {
  Plus, Save, Trash2, CalendarDays, Users, Search, Loader2, ExternalLink, Mic, Square, FileText
} from "lucide-react"
import VoiceNotesPanel from "../_components/VoiceNotesPanel.client"

type Session = {
  id: string
  scout_id: string
  title: string | null
  match_date: string | null
  competition: string | null
  opponent: string | null
  notes: string | null
}

type Row = {
  id: string
  observation_id: string
  player_id: string | null
  player_entry_id: string | null
  minutes_watched: number | null
  rating: number | null
  notes: string | null
  players?: { id: string; full_name: string; image_url: string | null; transfermarkt_url: string | null } | null
  scout_player_entries?: { id: string; full_name: string; image_url: string | null; transfermarkt_url: string | null } | null
}

type Props = { session: Session; rows: Row[] }

const FALLBACK_SVG =
  "data:image/svg+xml;utf8," +
  encodeURIComponent(
    '<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64"><rect width="100%" height="100%" fill="#e5e7eb"/><text x="50%" y="50%" dominant-baseline="middle" text-anchor="middle" font-size="10" fill="#9ca3af">No Img</text></svg>'
  )

const LANGUAGE = "pl"
const MAX_SECONDS = 60

export default function ObservationEditor({ session: initial, rows: initialRows }: Props) {
  const supabase = createClient()

  /** ---------------- Session meta (autosave) ---------------- */
  const [session, setSession] = useState<Session>(initial)
  const [savingMeta, setSavingMeta] = useState(false)
  const metaTimer = useRef<ReturnType<typeof setTimeout> | null>(null)

  const onMetaChange = <K extends keyof Session>(key: K, val: Session[K]) => {
    setSession((s) => ({ ...s, [key]: val }))
    if (metaTimer.current) clearTimeout(metaTimer.current)
    metaTimer.current = setTimeout(async () => {
      setSavingMeta(true)
      try {
        const { error } = await supabase
          .from("observation_sessions")
          .update({ [key]: val })
          .eq("id", initial.id)
          .select("id")
          .maybeSingle()
        if (error) throw error
      } catch (e: any) {
        toast.error(e?.message || "Failed to save")
      } finally {
        setSavingMeta(false)
      }
    }, 500)
  }

  /** ---------------- Player rows (table) ---------------- */
  const [rows, setRows] = useState<Row[]>(initialRows)
  type Draft = Pick<Row, "minutes_watched" | "rating" | "notes">
  const [dirty, setDirty] = useState<Record<string, Draft>>({})
  const [savingRow, setSavingRow] = useState<Record<string, boolean>>({})

  const setRowDraft = (id: string, patch: Partial<Draft>) => {
    setDirty((d) => ({ ...d, [id]: { ...d[id], ...patch } }))
  }
  const showRowSave = (id: string) => !!dirty[id]

  const saveRow = async (id: string) => {
    const patch = dirty[id]
    if (!patch) return
    setSavingRow((s) => ({ ...s, [id]: true }))
    try {
      const r = await fetch(`/scout/observations/players/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(j.error || "Save failed")
      setRows((prev) => prev.map((row) => (row.id === id ? { ...row, ...patch } : row)))
      setDirty((d) => {
        const { [id]: _, ...rest } = d
        return rest
      })
      toast.success("Saved")
    } catch (e: any) {
      toast.error(e?.message || "Save failed")
    } finally {
      setSavingRow((s) => ({ ...s, [id]: false }))
    }
  }

  const deleteRow = async (id: string) => {
    if (!confirm("Remove player from this observation?")) return
    setSavingRow((s) => ({ ...s, [id]: true }))
    try {
      const r = await fetch(`/scout/observations/players/${id}`, { method: "DELETE" })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(j.error || "Delete failed")
      setRows((prev) => prev.filter((row) => row.id !== id))
      setDirty((d) => {
        const { [id]: _, ...rest } = d
        return rest
      })
      toast.success("Removed")
    } catch (e: any) {
      toast.error(e?.message || "Delete failed")
    } finally {
      setSavingRow((s) => ({ ...s, [id]: false }))
    }
  }

  /** ---------------- Live search (players + entries) ---------------- */
  const [query, setQuery] = useState("")
  const [searching, setSearching] = useState(false)
  const [results, setResults] = useState<
    { type: "player" | "entry"; id: string; full_name: string; image_url: string | null; tm?: string | null }[]
  >([])

  useEffect(() => {
    const t = setTimeout(async () => {
      const q = query.trim()
      if (!q) {
        setResults([])
        return
      }
      setSearching(true)
      try {
        const [p1, p2] = await Promise.all([
          supabase
            .from("players")
            .select("id, full_name, image_url, transfermarkt_url")
            .ilike("full_name", `%${q}%`)
            .limit(10),
          supabase
            .from("scout_player_entries")
            .select("id, full_name, image_url, transfermarkt_url")
            .ilike("full_name", `%${q}%`)
            .limit(10),
        ])
        const A =
          (p1.data || []).map((p) => ({
            type: "player" as const,
            id: p.id,
            full_name: p.full_name,
            image_url: p.image_url,
            tm: (p as any).transfermarkt_url || null,
          })) ?? []
        const B =
          (p2.data || []).map((p) => ({
            type: "entry" as const,
            id: p.id,
            full_name: p.full_name,
            image_url: p.image_url,
            tm: (p as any).transfermarkt_url || null,
          })) ?? []
        const seen = new Set<string>()
        const merged = [...A, ...B].filter((r) => {
          const k = `${r.type}:${r.id}`
          if (seen.has(k)) return false
          seen.add(k)
          return true
        })
        setResults(merged)
      } catch {
        setResults([])
      } finally {
        setSearching(false)
      }
    }, 250)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [query])

  const alreadyInList = (rec: { type: "player" | "entry"; id: string }) =>
    rows.some((r) => (rec.type === "player" ? r.player_id === rec.id : r.player_entry_id === rec.id))

  const addToObservation = async (rec: { type: "player" | "entry"; id: string }) => {
    if (alreadyInList(rec)) {
      toast.message("Already added", { description: "This player is already in this observation." })
      return
    }
    try {
      const payload = rec.type === "player" ? { player_id: rec.id } : { player_entry_id: rec.id }

      const r = await fetch(`/scout/observations/${session.id}/players`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      const j = await r.json().catch(() => ({}))
      if (!r.ok) throw new Error(j.error || "Add failed")

      const newRow: Row =
        j?.row ?? {
          id: crypto.randomUUID(),
          observation_id: session.id,
          player_id: payload.player_id ?? null,
          player_entry_id: payload.player_entry_id ?? null,
          minutes_watched: 0,
          rating: null,
          notes: "",
          players: undefined,
          scout_player_entries: undefined,
        }

      setRows((prev) => [newRow, ...prev])
      toast.success("Added")
      setQuery("")
      setResults([])
    } catch (e: any) {
      toast.error(e?.message || "Add failed")
    }
  }

  /** ---------------- Refresh keys for notes panels ---------------- */
  const [obsNotesKey, setObsNotesKey] = useState(0)
  const [rowNotesKey, setRowNotesKey] = useState<Record<string, number>>({})
  const bumpRowKey = (rowId: string) =>
    setRowNotesKey((m) => ({ ...m, [rowId]: (m[rowId] || 0) + 1 }))

  /** ---------------- Minimal inline recorder (with REC pulse + toasts) ---------------- */
function InlineRecorder({
  observationId,
  playerId,
  observationPlayerId,
  onSaved,
}: {
  observationId: string
  playerId?: string
  observationPlayerId?: string
  onSaved?: () => void
}) {
  const mediaRecorderRef = useRef<MediaRecorder | null>(null)
  const chunksRef = useRef<BlobPart[]>([])
  const [recording, setRecording] = useState(false)
  const [seconds, setSeconds] = useState(0)
  const timerRef = useRef<number | null>(null)
  const [busy, setBusy] = useState(false)

  // Browser speech recognition (live)
  const recognitionRef = useRef<any>(null)
  const [liveText, setLiveText] = useState("")

  const getSupportedMime = () => {
    // @ts-ignore
    if (typeof MediaRecorder === "undefined") return undefined
    const cands = ["audio/webm;codecs=opus", "audio/webm", "audio/ogg;codecs=opus", "audio/mp4"]
    // @ts-ignore
    for (const c of cands) if (MediaRecorder.isTypeSupported?.(c)) return c
    return undefined
  }

  const startRecognition = () => {
    try {
      const SR: any =
        (globalThis as any).SpeechRecognition ||
        (globalThis as any).webkitSpeechRecognition
      if (!SR) return // silently skip if not available

      const rec = new SR()
      rec.lang = LANGUAGE
      rec.continuous = true
      rec.interimResults = true

      rec.onresult = (e: any) => {
        let finalText = ""
        for (let i = e.resultIndex; i < e.results.length; i++) {
          const res = e.results[i]
          if (res.isFinal) finalText += res[0].transcript
        }
        if (finalText) setLiveText((t) => (t ? `${t} ${finalText}` : finalText))
      }
      rec.onerror = (ev: any) => {
        // optional: show a gentle info toast, but don't block recording
        console.warn("SpeechRecognition error:", ev?.error)
      }
      rec.onend = () => {
        // if still recording, keep it alive
        if (recording) {
          try {
            rec.start()
          } catch {}
        }
      }

      recognitionRef.current = rec
      rec.start()
    } catch (e) {
      console.warn("SpeechRecognition init failed:", e)
    }
  }

  const stopRecognition = () => {
    try {
      recognitionRef.current?.stop?.()
    } catch {}
    recognitionRef.current = null
  }

  const start = async () => {
    try {
      if (!(location.protocol === "https:" || location.hostname === "localhost")) {
        toast.error("Microphone requires HTTPS (or localhost)")
        return
      }
      // @ts-ignore
      if (typeof MediaRecorder === "undefined") {
        toast.error("Recording not supported in this browser")
        return
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true },
      })
      const mime = getSupportedMime()
      const rec = mime ? new MediaRecorder(stream, { mimeType: mime }) : new MediaRecorder(stream)
      chunksRef.current = []
      rec.ondataavailable = (e) => {
        if (e.data.size > 0) chunksRef.current.push(e.data)
      }
      rec.onstop = () => {
        stream.getTracks().forEach((t) => t.stop())
        void save()
      }
      rec.start(250)
      mediaRecorderRef.current = rec
      setRecording(true)
      setSeconds(0)
      setLiveText("") // reset live transcript

      // UI feedback
      toast.message("Recording…", { description: `Up to ${MAX_SECONDS}s` })

      startRecognition()

      timerRef.current = window.setInterval(() => {
        setSeconds((s) => {
          if (s + 1 >= MAX_SECONDS) stop()
          return s + 1
        })
      }, 1000)
    } catch (e: any) {
      const name = e?.name || ""
      if (name === "NotAllowedError") toast.error("Mic permission denied")
      else if (name === "NotFoundError") toast.error("No microphone found")
      else if (name === "NotReadableError") toast.error("Microphone busy")
      else toast.error(e?.message || "Unable to start")
    }
  }

  const stop = () => {
    try {
      if (mediaRecorderRef.current && mediaRecorderRef.current.state !== "inactive") {
        mediaRecorderRef.current.stop()
      }
    } catch {}
    setRecording(false)
    if (timerRef.current) {
      clearInterval(timerRef.current)
      timerRef.current = null
    }
    stopRecognition()
    toast.success("Recording stopped")
  }

  const save = async () => {
    if (!chunksRef.current.length) return
    setBusy(true)
    try {
      const uid = (await supabase.auth.getUser()).data.user?.id
      if (!uid) {
        toast.error("Not authenticated")
        return
      }
      const voiceId = crypto.randomUUID()
      const mime = mediaRecorderRef.current?.mimeType || "audio/webm"
      const file = new Blob(chunksRef.current, { type: mime })
      const path = `${uid}/${observationId}/${voiceId}.webm`

      const { error: upErr } = await supabase.storage.from("obs-audio").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
        contentType: mime,
      })
      if (upErr) {
        toast.error(upErr.message)
        return
      }

      // Send browser transcript (if any) so DB is "done" immediately
      const resp = await fetch(`/scout/observations/voice-notes`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          observationId,
          observationPlayerId,
          playerId,
          storagePath: path,
          durationSec: seconds,
          language: LANGUAGE,
          transcript: liveText?.trim() || undefined,
        }),
      })

      const j = await resp.json().catch(() => ({}))
      if (!resp.ok || !j.ok) {
        toast.error(j.error || "Failed to save voice note")
        return
      }

      toast.success(liveText?.trim() ? "Saved with browser transcript" : "Saved")
      onSaved?.()
    } finally {
      setBusy(false)
      chunksRef.current = []
    }
  }

  return (
    <div className="flex items-center gap-2">
      <div className="relative">
        {!recording ? (
          <Button size="sm" onClick={start} className="h-8 px-2" disabled={busy}>
            <Mic className="h-4 w-4" />
          </Button>
        ) : (
          <Button size="sm" variant="destructive" onClick={stop} className="h-8 px-2">
            <Square className="h-4 w-4" />
          </Button>
        )}
        {recording && (
          <span className="absolute -top-1 -right-1 h-2 w-2 rounded-full bg-red-500 animate-ping" />
        )}
      </div>
      <span className={`text-xs tabular-nums w-[42px] text-right ${recording ? "text-red-500 animate-pulse" : "text-muted-foreground"}`}>
        {seconds}s
      </span>
    </div>
  )
}



  /** ---------------- Notes panel toggles ---------------- */
  const [openObsNotes, setOpenObsNotes] = useState(false)
  const [openNotesByRow, setOpenNotesByRow] = useState<Record<string, boolean>>({})
  const toggleRowNotes = (rowId: string, forceOpen?: boolean) =>
    setOpenNotesByRow((s) => ({ ...s, [rowId]: forceOpen ?? !s[rowId] }))

  /** ---------------- Derived helpers ---------------- */
  const totalPlayers = rows.length
  const titlePlaceholder =
    session.competition && session.opponent
      ? `${session.competition} • vs ${session.opponent}`
      : "Session title (optional)"
  const formatDate = (d?: string | null) => d || ""

  return (
    <div className="space-y-6">
      {/* Header / Meta */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div className="min-w-0 flex-1">
          <Input
            value={session.title ?? ""}
            onChange={(e) => onMetaChange("title", e.target.value)}
            placeholder={titlePlaceholder}
            className="text-lg font-semibold"
          />
          <div className="mt-2 grid grid-cols-1 gap-2 sm:grid-cols-3">
            <Input
              value={formatDate(session.match_date)}
              onChange={(e) => onMetaChange("match_date", e.target.value)}
              placeholder="YYYY-MM-DD"
              type="date"
            />
            <Input
              value={session.competition ?? ""}
              onChange={(e) => onMetaChange("competition", e.target.value)}
              placeholder="Competition"
            />
            <Input
              value={session.opponent ?? ""}
              onChange={(e) => onMetaChange("opponent", e.target.value)}
              placeholder="Opponent"
            />
          </div>
          <div className="mt-1 text-xs text-muted-foreground flex items-center gap-3">
            <span className="inline-flex items-center gap-1">
              <CalendarDays className="h-3.5 w-3.5" />
              Autosave: {savingMeta ? "saving…" : "idle"}
            </span>
            <Badge variant="secondary" className="gap-1">
              <Users className="h-3.5 w-3.5" /> {totalPlayers} player{totalPlayers === 1 ? "" : "s"}
            </Badge>
          </div>
        </div>

        <div className="sm:w-80">
          <div className="text-xs font-medium mb-1">Observation notes</div>
          <Textarea
            rows={4}
            value={session.notes ?? ""}
            onChange={(e) => onMetaChange("notes", e.target.value)}
            placeholder="General notes about this match/session…"
          />
        </div>
      </div>

      {/* Observation-level: minimal recorder toolbar */}
      <Card className="p-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">Voice</span>
            <InlineRecorder
              observationId={session.id}
              onSaved={() => {
                setOpenObsNotes(true)
                setObsNotesKey((k) => k + 1) // refresh VoiceNotesPanel via key remount
              }}
            />
          </div>
          <Button size="sm" variant={openObsNotes ? "secondary" : "outline"} onClick={() => setOpenObsNotes((v) => !v)}>
            <FileText className="h-4 w-4 mr-1" /> {openObsNotes ? "Hide notes" : "Show notes"}
          </Button>
        </div>
        {openObsNotes && (
          <div className="mt-2">
            <VoiceNotesPanel
              key={obsNotesKey}
              observationId={session.id}
              title="Observation voice notes"
            />
          </div>
        )}
      </Card>

      {/* Add players – live search */}
      <Card className="p-4">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <div className="relative flex-1">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              className="pl-8"
              placeholder="Type to search players for observations.."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
            />
            {searching && (
              <Loader2 className="absolute right-2 top-2.5 h-4 w-4 animate-spin text-muted-foreground" />
            )}
          </div>
        </div>

        {!!results.length && (
          <div className="mt-3 grid gap-2 sm:grid-cols-2">
            {results.map((r) => (
              <Card key={`${r.type}-${r.id}`} className="p-3 flex items-center justify-between">
                <div className="min-w-0 flex items-center gap-3">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img
                    src={r.image_url || FALLBACK_SVG}
                    alt={r.full_name}
                    className="h-8 w-8 rounded-md object-cover border"
                  />
                  <div className="min-w-0">
                    <div className="text-sm font-medium truncate">{r.full_name}</div>
                    <div className="text-[11px] text-muted-foreground flex items-center gap-2">
                      <Badge variant={r.type === "player" ? "secondary" : "outline"} className="px-1 py-0 h-5">
                        {r.type === "player" ? "Canonical" : "Entry"}
                      </Badge>
                      {r.tm && (
                        <a
                          href={r.tm}
                          target="_blank"
                          rel="noreferrer"
                          className="inline-flex items-center gap-1 underline"
                          title="Transfermarkt"
                        >
                          TM <ExternalLink className="h-3.5 w-3.5" />
                        </a>
                      )}
                    </div>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  className="gap-2"
                  onClick={() => addToObservation(r)}
                  disabled={alreadyInList(r)}
                >
                  <Plus className="h-4 w-4" /> {alreadyInList(r) ? "Added" : "Add"}
                </Button>
              </Card>
            ))}
          </div>
        )}

        {!results.length && query.trim() && !searching && (
          <div className="mt-2 text-xs text-muted-foreground">
            No results. Try a different name or create a new player/entry first.
          </div>
        )}
      </Card>

      {/* Dynamic table */}
{/* Players list (no table) */}
<Card className="p-0">
  <div className="p-2 sm:p-3">
    {/* Optional tiny header legend (muted, collapses nicely) */}
    <div className="hidden md:grid grid-cols-[1fr_auto_auto_auto_auto] gap-3 px-1 pb-2 text-[11px] text-muted-foreground">
      <span>Player</span>
      <span className="w-[88px]">Type</span>
      <span className="w-[96px] text-right">Minutes</span>
      <span className="w-[96px] text-right">Rating</span>
      <span className="w-[120px]">Voice</span>
      {/* actions are self-explanatory */}
    </div>

    <div className="space-y-2">
      {rows.map((row) => {
        const p = row.players ?? row.scout_player_entries
        const type = row.player_id ? "Canonical" : "Entry"
        const isSaving = !!savingRow[row.id]
        const isNotesOpen = !!openNotesByRow[row.id]
        const isDirty = !!dirty[row.id]

        return (
          <Card
            key={row.id}
            className={`border transition-colors ${
              isDirty ? "bg-amber-50/40 dark:bg-amber-950/20" : "bg-card"
            }`}
          >
            {/* Row body */}
            <div className="p-3 grid gap-3
                            md:grid-cols-[1fr_auto_auto_auto_auto_auto]
                            md:items-center">
              {/* Player */}
              <div className="min-w-0 flex items-start gap-3">
                {/* eslint-disable-next-line @next/next/no-img-element */}
                <img
                  src={p?.image_url || FALLBACK_SVG}
                  alt={p?.full_name || "Player"}
                  className="h-10 w-10 rounded-md object-cover border"
                />
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <div className="font-medium truncate">{p?.full_name ?? "(unknown)"}</div>
                    {isDirty && <span className="h-1.5 w-1.5 rounded-full bg-amber-500" title="Unsaved changes" />}
                  </div>
                  <div className="mt-1 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    {row.player_id && <Badge variant="secondary">Players table</Badge>}
                    {row.player_entry_id && <Badge variant="outline">Scout entry</Badge>}
                    {p?.transfermarkt_url && (
                      <a
                        href={p.transfermarkt_url}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 underline hover:text-foreground"
                      >
                        TM <ExternalLink className="h-3.5 w-3.5" />
                      </a>
                    )}
                    {/* On small screens we also show the type here */}
                    <span className="md:hidden inline-flex items-center gap-1">
                      • <span className="font-medium">{type}</span>
                    </span>
                  </div>
                </div>
              </div>

              {/* Type (desktop only) */}
              <div className="hidden md:block w-[88px] text-xs text-muted-foreground">{type}</div>

              {/* Minutes */}
              <div className="grid gap-1 w-[96px]">
                <label className="md:hidden text-[11px] text-muted-foreground">Minutes</label>
                <Input
                  inputMode="numeric"
                  type="number"
                  min={0}
                  className="h-8 text-right"
                  defaultValue={row.minutes_watched ?? 0}
                  onChange={(e) =>
                    setRowDraft(row.id, { minutes_watched: Number(e.target.value || 0) })
                  }
                  aria-label="Minutes watched"
                />
              </div>

              {/* Rating */}
              <div className="grid gap-1 w-[96px]">
                <label className="md:hidden text-[11px] text-muted-foreground">Rating</label>
                <Input
                  inputMode="numeric"
                  type="number"
                  min={1}
                  max={10}
                  className="h-8 text-right"
                  defaultValue={row.rating ?? ""}
                  onChange={(e) =>
                    setRowDraft(row.id, {
                      rating: e.target.value ? Number(e.target.value) : null,
                    })
                  }
                  aria-label="Rating"
                />
              </div>

              {/* Voice */}
              <div className="w-[120px]">
                <div className="grid gap-1">
                  <label className="md:hidden text-[11px] text-muted-foreground">Voice</label>
                  <InlineRecorder
                    observationId={session.id}
                    playerId={row.player_id ?? undefined}
                    observationPlayerId={row.id}
                    onSaved={() => {
                      toggleRowNotes(row.id, true)
                      bumpRowKey(row.id)
                    }}
                  />
                </div>
              </div>

              {/* Actions */}
              <div className="flex flex-wrap items-center justify-end gap-1.5">
                {isDirty && (
                  <Button
                    size="sm"
                    className="gap-2"
                    onClick={() => saveRow(row.id)}
                    disabled={!isDirty || isSaving}
                    aria-label="Save row"
                  >
                    {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
                    <span className="hidden md:inline">Save</span>
                  </Button>
                )}

                <Button
                  size="sm"
                  variant="outline"
                  className="gap-2"
                  onClick={() => deleteRow(row.id)}
                  disabled={isSaving}
                  aria-label="Remove row"
                >
                  <Trash2 className="h-4 w-4" />
                  <span className="hidden md:inline">Remove</span>
                </Button>

                <Button
                  size="sm"
                  variant={isNotesOpen ? "secondary" : "outline"}
                  className="gap-2"
                  onClick={() => toggleRowNotes(row.id)}
                  aria-expanded={isNotesOpen}
                  aria-controls={`notes-${row.id}`}
                >
                  <FileText className="h-4 w-4" />
                  <span className="hidden md:inline">{isNotesOpen ? "Hide notes" : "Notes"}</span>
                </Button>
              </div>

              {/* Notes editor (inline on desktop; auto-collapses on mobile via the Notes toggle) */}
              <div className="md:col-span-6">
                <div className="hidden md:block">
                  <Textarea
                    rows={2}
                    className="w-full"
                    defaultValue={row.notes ?? ""}
                    onChange={(e) => setRowDraft(row.id, { notes: e.target.value })}
                    placeholder="Notes for this player…"
                    aria-label="Player notes"
                  />
                </div>
              </div>
            </div>

            {/* Collapsible: voice notes panel (below row) */}
            {isNotesOpen && (
              <div id={`notes-${row.id}`} className="border-t p-3">
                <VoiceNotesPanel
                  key={rowNotesKey[row.id] || 0}
                  observationId={session.id}
                  playerId={row.player_id ?? undefined}
                  observationPlayerId={row.id}
                  title="Player voice notes"
                />
              </div>
            )}

            {/* On small screens, show the text notes editor only when notes panel is open (to keep UI minimal) */}
            {isNotesOpen && (
              <div className="md:hidden border-t p-3 pt-2">
                <Textarea
                  rows={3}
                  className="w-full"
                  defaultValue={row.notes ?? ""}
                  onChange={(e) => setRowDraft(row.id, { notes: e.target.value })}
                  placeholder="Notes for this player…"
                  aria-label="Player notes (mobile)"
                />
              </div>
            )}
          </Card>
        )
      })}

      {!rows.length && (
        <Card className="p-6 text-center text-xs text-muted-foreground">
          No players yet. Use the search above to add players to this observation.
        </Card>
      )}
    </div>
  </div>
</Card>

    </div>
  )
}
