"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"
import { Search, Shield } from "lucide-react"

type Scout = {
  id: string
  full_name: string | null
  avatar_url: string | null
  country: string | null
  agency: string | null
  role: "scout" | "admin"
  is_active: boolean
  created_at: string
  myPlayersCount: number
  entriesCount: number
}

export default function ScoutsTable() {
  const [q, setQ] = useState("")
  const [rolesFilter, setRolesFilter] = useState<{ scout: boolean; admin: boolean }>({ scout: false, admin: false })
  const [loading, setLoading] = useState(false)
  const [rows, setRows] = useState<Scout[]>([])
  const [pending, setPending] = useState<Record<string, boolean>>({})
  const debounceRef = useRef<number | null>(null)

  const selectedRoleParam = () => {
    // Only filter when exactly one role is selected; otherwise show all
    if (rolesFilter.scout && !rolesFilter.admin) return "scout" as const
    if (rolesFilter.admin && !rolesFilter.scout) return "admin" as const
    return undefined
  }

  const load = async () => {
    setLoading(true)
    try {
      const url = new URL("/api/admin/scouts/list", location.origin)
      if (q.trim()) url.searchParams.set("q", q.trim())
      const role = selectedRoleParam()
      if (role) url.searchParams.set("role", role)
      const res = await fetch(url.toString(), { cache: "no-store" })
      const json = await res.json()
      if (!res.ok) throw new Error(json.error || "Failed to load scouts")
      setRows(json.scouts || [])
    } catch (e: any) {
      toast.error(e.message)
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  // initial
  useEffect(() => { load() }, []) // eslint-disable-line react-hooks/exhaustive-deps

  // refetch on role filter change
  useEffect(() => { load() }, [rolesFilter.scout, rolesFilter.admin]) // eslint-disable-line react-hooks/exhaustive-deps

  // debounced search
  useEffect(() => {
    if (debounceRef.current) window.clearTimeout(debounceRef.current)
    debounceRef.current = window.setTimeout(() => load(), 300)
    return () => { if (debounceRef.current) window.clearTimeout(debounceRef.current) }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q])

  const filtered = useMemo(() => rows, [rows])

  const toggleActive = async (id: string, next: boolean) => {
    if (pending[id]) return
    setPending(s => ({ ...s, [id]: true }))
    try {
      const res = await fetch("/api/admin/scouts/toggle-active", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scout_id: id, is_active: next }),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(body.error || "Failed to update")
      setRows(list => list.map(s => (s.id === id ? { ...s, is_active: next } : s)))
      toast.success(next ? "Scout activated" : "Scout deactivated")
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setPending(s => ({ ...s, [id]: false }))
    }
  }

  const setRole = async (id: string, role: "scout" | "admin") => {
    if (pending[id]) return
    setPending(s => ({ ...s, [id]: true }))
    try {
      const res = await fetch("/api/admin/scouts/set-role", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ scout_id: id, role }),
      })
      const body = await res.json().catch(() => ({}))
      if (!res.ok) throw new Error(body.error || "Failed to update role")
      setRows(list => list.map(s => (s.id === id ? { ...s, role } : s)))
      toast.success(role === "admin" ? "Promoted to admin" : "Set to scout")
    } catch (e: any) {
      toast.error(e.message)
    } finally {
      setPending(s => ({ ...s, [id]: false }))
    }
  }

  const resetFilters = () => {
    setQ("")
    setRolesFilter({ scout: false, admin: false })
    load()
  }

  return (
    <div className="space-y-4">
      {/* Controls */}
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        {/* Search */}
        <div className="relative w-full sm:max-w-sm">
          <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            className="pl-8"
            placeholder="Search name, agency, country…"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter") load() }}
          />
        </div>

        {/* Role filter (checkboxes) */}
        <div className="flex items-center gap-4 border rounded-md px-3 py-2">
          <div className="flex items-center gap-2">
            <Checkbox
              id="role-scout"
              checked={rolesFilter.scout}
              onCheckedChange={(v) => setRolesFilter(r => ({ ...r, scout: Boolean(v) }))}
            />
            <Label htmlFor="role-scout" className="text-sm">Scout</Label>
          </div>
          <div className="flex items-center gap-2">
            <Checkbox
              id="role-admin"
              checked={rolesFilter.admin}
              onCheckedChange={(v) => setRolesFilter(r => ({ ...r, admin: Boolean(v) }))}
            />
            <Label htmlFor="role-admin" className="text-sm">Admin</Label>
          </div>
          <span className="ml-2 text-xs text-muted-foreground">
            (Select one to filter; none or both = all)
          </span>
        </div>

        <Button variant="outline" onClick={resetFilters} disabled={loading}>
          Reset
        </Button>
        <Button onClick={load} disabled={loading}>{loading ? "Loading…" : "Refresh"}</Button>
      </div>

      {/* Grid list */}
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {filtered.map(s => {
          const isBusy = !!pending[s.id]
          const roleIsAdmin = s.role === "admin"

          return (
            <Card key={s.id} className="p-4 rounded-2xl shadow-sm flex gap-3">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img
                src={s.avatar_url || "/placeholder.svg"}
                alt={s.full_name ?? "Scout"}
                className="h-14 w-14 rounded-full object-cover border"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-2">
                  <div className="font-medium truncate">{s.full_name ?? "(no name)"}</div>
                  {roleIsAdmin ? (
                    <Badge variant="secondary" className="gap-1"><Shield className="h-3 w-3" /> Admin</Badge>
                  ) : (
                    <Badge variant="outline">Scout</Badge>
                  )}
                  {!s.is_active && <Badge variant="destructive">Inactive</Badge>}
                </div>

                <div className="text-xs text-muted-foreground truncate">
                  {s.agency || "—"}{s.country ? ` · ${s.country}` : ""}
                </div>
                <div className="text-xs mt-1 text-muted-foreground">
                  My Players: {s.myPlayersCount} · Entries: {s.entriesCount}
                </div>

                {/* Per-row role switch (checkboxes, mutually exclusive by handler) */}
                <div className="mt-3 flex items-center gap-4">
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id={`row-${s.id}-scout`}
                      checked={!roleIsAdmin}
                      disabled={isBusy}
                      onCheckedChange={(v) => { if (v) setRole(s.id, "scout") }}
                    />
                    <Label htmlFor={`row-${s.id}-scout`} className="text-sm">Scout</Label>
                  </div>
                  <div className="flex items-center gap-2">
                    <Checkbox
                      id={`row-${s.id}-admin`}
                      checked={roleIsAdmin}
                      disabled={isBusy}
                      onCheckedChange={(v) => { if (v) setRole(s.id, "admin") }}
                    />
                    <Label htmlFor={`row-${s.id}-admin`} className="text-sm">Admin</Label>
                  </div>

                  <Button
                    variant={s.is_active ? "outline" : "default"}
                    size="sm"
                    className="h-8 ml-auto"
                    disabled={isBusy}
                    onClick={() => toggleActive(s.id, !s.is_active)}
                  >
                    {s.is_active ? "Deactivate" : "Activate"}
                  </Button>
                </div>
              </div>
            </Card>
          )
        })}

        {!filtered.length && (
          <Card className="p-8 rounded-2xl shadow-sm col-span-full text-center text-sm text-muted-foreground">
            No scouts found.
          </Card>
        )}
      </div>
    </div>
  )
}
