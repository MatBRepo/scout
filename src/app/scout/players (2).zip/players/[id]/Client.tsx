"use client"

import { useEffect, useMemo, useRef, useState, useTransition } from "react"
import { createClient } from "@/lib/supabase/browser"
import { toast } from "sonner"
import Link from "next/link"


import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Separator } from "@/components/ui/separator"
import { Switch } from "@/components/ui/switch"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"

import { Calendar, Footprints, Flag, Building2, Save, Loader2, Trash2 } from "lucide-react"

const CATEGORIES = [
  { key: "motor", label: "Motor skills – speed, stamina" },
  { key: "strength_agility", label: "Strength, duels, agility" },
  { key: "technique", label: "Technique" },
  { key: "with_ball", label: "Moves with a ball" },
  { key: "without_ball", label: "Moves without a ball" },
  { key: "set_pieces", label: "Set pieces" },
  { key: "defensive", label: "Defensive phase" },
  { key: "attacking", label: "Attacking phase" },
  { key: "transitions", label: "Transitional phases" },
  { key: "attitude", label: "Attitude (mentality)" },
  { key: "final_comment", label: "Final comment" },
] as const

type Observation = {
  id: string
  match_date: string
  competition: string | null
  opponent: string | null
  minutes_watched: number | null
  notes: string | null
  created_at: string
}
type Note = {
  id: string
  category: string
  rating: number | null
  comment: string | null
  created_at: string
  updated_at: string
}

export default function Client({
  userId,
  player,
  observations,
  notes,
}: {
  userId: string
  player: any
  observations: Observation[]
  notes: Note[]
}) {
  const supabase = createClient()
  const [isSaving, startSaving] = useTransition()

  /* ---------------- Editable player form ---------------- */
  const [form, setForm] = useState({
    first_name: player.first_name ?? "",
    last_name: player.last_name ?? "",
    date_of_birth: player.date_of_birth ?? "",
    height_cm: player.height_cm ?? "",
    weight_kg: player.weight_kg ?? "",
    country_of_birth: player.country_of_birth ?? "",
    has_eu_passport: !!player.has_eu_passport,
    current_club_name: player.current_club_name ?? "",
    current_club_country: player.current_club_country ?? "",
    current_club_tier: player.current_club_tier ?? "",
    main_position: player.main_position ?? "",
    dominant_foot: player.dominant_foot ?? "",
    english_speaks: !!player.english_speaks,
    english_level: player.english_level ?? "",
    contact_phone: player.contact_phone ?? "",
    contact_email: player.contact_email ?? "",
    coach_contact: player.coach_contact ?? "",
    contract_status: player.contract_status ?? "",
    contract_until: player.contract_until ?? "",
    agency: player.agency ?? "",
    appearances: player.appearances ?? "",
    minutes: player.minutes ?? "",
    goals_last_season: player.goals_last_season ?? "",
    assists_last_season: player.assists_last_season ?? "",
    dribbles_last_season: player.dribbles_last_season ?? "",
    injuries_last_3y: player.injuries_last_3y ?? "",
    transfermarkt_url: player.transfermarkt_url ?? "",
  })
  function set<K extends keyof typeof form>(k: K, v: any) { setForm(p => ({ ...p, [k]: v })) }

  const REQUIRED_KEYS: (keyof typeof form)[] = [
    "first_name","last_name","date_of_birth","main_position","dominant_foot",
    "current_club_name","current_club_country","current_club_tier",
    "height_cm","weight_kg","country_of_birth","english_level","contact_email",
  ]
  const completeness = useMemo(() => {
    const total = REQUIRED_KEYS.length
    const filled = REQUIRED_KEYS.reduce((acc, k) => acc + (String(form[k] ?? "").toString().trim() ? 1 : 0), 0)
    return Math.round((filled / total) * 100)
  }, [form])

  const save = () => {
    startSaving(async () => {
      const payload: any = {
        ...form,
        height_cm: form.height_cm ? Number(form.height_cm) : null,
        weight_kg: form.weight_kg ? Number(form.weight_kg) : null,
        current_club_tier: form.current_club_tier ? Number(form.current_club_tier) : null,
        appearances: form.appearances ? Number(form.appearances) : null,
        minutes: form.minutes ? Number(form.minutes) : null,
        goals_last_season: form.goals_last_season ? Number(form.goals_last_season) : null,
        assists_last_season: form.assists_last_season ? Number(form.assists_last_season) : null,
        dribbles_last_season: form.dribbles_last_season ? Number(form.dribbles_last_season) : null,
        injuries_last_3y: form.injuries_last_3y ? Number(form.injuries_last_3y) : null,
        full_name: `${(form.first_name||"").trim()} ${(form.last_name||"").trim()}`.trim(),
      }
      const { error } = await supabase.from("players").update(payload).eq("id", player.id)
      if (error) toast.error(error.message)
      else toast.success("Player updated", { description: payload.full_name })
    })
  }

  /* ---------------- Notes (Windows sticky style) ---------------- */
  // Build per-category state from existing notes (only current scout, enforced by server + RLS)
  type CatState = { id?: string; rating: number; comment: string; saving?: boolean; savedAt?: number }
  const initialNotesState: Record<string, CatState> = useMemo(() => {
    const state: Record<string, CatState> = {}
    CATEGORIES.forEach(c => {
      const n = notes.find(nn => nn.category === c.key)
      state[c.key] = {
        id: n?.id,
        rating: n?.rating ?? 0,
        comment: n?.comment ?? "",
      }
    })
    return state
  }, [notes])

  const [catNotes, setCatNotes] = useState<Record<string, CatState>>(initialNotesState)
  const saveTimers = useRef<Record<string, any>>({})

  function setCat(cat: string, patch: Partial<CatState>, autosave = true) {
    setCatNotes(prev => {
      const next = { ...prev, [cat]: { ...prev[cat], ...patch } }
      return next
    })
    if (!autosave) return
    // debounce 500ms per category
    if (saveTimers.current[cat]) clearTimeout(saveTimers.current[cat])
    saveTimers.current[cat] = setTimeout(() => persistNote(cat), 500)
  }

  async function persistNote(cat: string) {
    const s = catNotes[cat]
    if (!s) return
    const payload = {
      scout_id: userId,
      player_id: player.id,
      category: cat,
      rating: s.rating || null,
      comment: s.comment?.trim() ? s.comment : null,
    }
    setCat(cat, { saving: true }, false)
    try {
      if (s.id) {
        const { error } = await supabase.from("scout_notes").update(payload).eq("id", s.id)
        if (error) throw error
      } else {
        const { data, error } = await supabase.from("scout_notes").insert(payload).select("id").single()
        if (error) throw error
        setCat(cat, { id: data?.id }, false)
      }
      setCat(cat, { saving: false, savedAt: Date.now() }, false)
      // toast not necessary on every keystroke; keep UI calm
    } catch (e: any) {
      setCat(cat, { saving: false }, false)
      toast.error(e?.message || "Failed to save note")
    }
  }

  async function deleteNote(cat: string) {
    const s = catNotes[cat]
    if (s?.id) {
      const { error } = await supabase.from("scout_notes").delete().eq("id", s.id)
      if (error) return toast.error(error.message)
    }
    setCat(cat, { id: undefined, rating: 0, comment: "" }, false)
    toast.success("Note removed")
  }

  /* ---------------- Observations (right column) ---------------- */
  const [obs, setObs] = useState<Observation[]>(observations)
  const [sessions, setSessions] = useState<{ id: string; title: string | null; match_date: string }[]>([])
  const [chosenSession, setChosenSession] = useState<string>("")

  useEffect(() => {
    ;(async () => {
      const { data } = await supabase
        .from("observation_sessions")
        .select("id, title, match_date")
        .eq("scout_id", userId)
        .order("match_date", { ascending: false })
      setSessions(data || [])
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  async function addToObservation() {
    if (!chosenSession) return toast.info("Choose an observation session first")
    const { error } = await supabase.from("observation_players").insert({
      observation_id: chosenSession,
      player_id: player.id,
      minutes_watched: null,
      rating: null,
      notes: null,
    })
    if (error) return toast.error(error.message)
    toast.success("Player added to observation")
    // refresh the observations list (optional helper)
    const sess = sessions.find(s => s.id === chosenSession)
    if (sess?.match_date) {
      await supabase.from("observations").insert({
        scout_id: userId, player_id: player.id, match_date: sess.match_date,
        competition: null, opponent: null, minutes_watched: null, notes: null,
      }).catch(()=>{})
      const { data } = await supabase
        .from("observations")
        .select("id, match_date, competition, opponent, minutes_watched, notes, created_at")
        .eq("player_id", player.id).eq("scout_id", userId)
        .order("match_date", { ascending: false })
      setObs(data || [])
    }
  }

  /* ---------------- Render ---------------- */
  return (
    // 100% width view
    <div className="w-full space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4 px-4 md:px-0">
        {player.image_url
          ? <img src={player.image_url} alt={player.full_name} className="h-20 w-20 rounded-xl object-cover border" />
          : <div className="h-20 w-20 rounded-xl bg-muted grid place-items-center text-xs text-muted-foreground">No photo</div>
        }
        <div className="min-w-0">
          <h1 className="text-2xl font-semibold">{player.full_name}</h1>
          <div className="text-sm text-muted-foreground">
            {player.main_position ? `Pos: ${player.main_position}` : "—"}
            {player.current_club_name ? ` · ${player.current_club_name}` : ""}
            {player.current_club_country ? ` (${player.current_club_country})` : ""}
          </div>
        </div>
      </div>

      {/* Progress */}
      <Card className="p-4 md:p-6 rounded-2xl mx-0 md:mx-0">
        <div className="flex items-center justify-between">
          <div className="text-sm font-medium">Profile completion</div>
          <div className="text-sm text-muted-foreground">{completeness}%</div>
        </div>
        <div className="mt-2 h-3 w-full rounded-full bg-muted overflow-hidden">
          <div className="h-3 bg-primary transition-all" style={{ width: `${completeness}%` }} />
        </div>
      </Card>

      {/* Editable info */}
      <Card className="p-4 md:p-6 rounded-2xl space-y-6 mx-0 md:mx-0">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Player information</h2>
          <Button onClick={save} disabled={isSaving}>
            {isSaving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving</> : <><Save className="h-4 w-4 mr-2" />Save</>}
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          <Field label="First name"><Input value={form.first_name} onChange={e=>set("first_name", e.target.value)} /></Field>
          <Field label="Last name"><Input value={form.last_name} onChange={e=>set("last_name", e.target.value)} /></Field>
          <Field label="Date of birth" icon={<Calendar className="h-4 w-4" />}><Input type="date" value={form.date_of_birth} onChange={e=>set("date_of_birth", e.target.value)} /></Field>

          <Field label="Height (cm)"><Input type="number" value={form.height_cm} onChange={e=>set("height_cm", e.target.value)} /></Field>
          <Field label="Weight (kg)"><Input type="number" value={form.weight_kg} onChange={e=>set("weight_kg", e.target.value)} /></Field>
          <Field label="Country of birth" icon={<Flag className="h-4 w-4" />}><Input value={form.country_of_birth} onChange={e=>set("country_of_birth", e.target.value)} /></Field>

          <ToggleField label="EU passport" checked={form.has_eu_passport} onChange={(v)=>set("has_eu_passport", v)} />
          <ToggleField label="Speaks English" checked={form.english_speaks} onChange={(v)=>set("english_speaks", v)} />
          <Field label="English level"><Input value={form.english_level} onChange={e=>set("english_level", e.target.value)} placeholder="A2/B1/B2/C1" /></Field>

          <Field label="Current club" icon={<Building2 className="h-4 w-4" />}><Input value={form.current_club_name} onChange={e=>set("current_club_name", e.target.value)} /></Field>
          <Field label="Club country"><Input value={form.current_club_country} onChange={e=>set("current_club_country", e.target.value)} /></Field>
          <Field label="League level"><Input type="number" value={form.current_club_tier} onChange={e=>set("current_club_tier", e.target.value)} /></Field>

          <Field label="Main position"><Input value={form.main_position} onChange={e=>set("main_position", e.target.value)} placeholder="e.g. CM, ST" /></Field>
          <Field label="Dominant foot" icon={<Footprints className="h-4 w-4" />}><Input value={form.dominant_foot} onChange={e=>set("dominant_foot", e.target.value)} placeholder="left / right / both" /></Field>
          <div />

          <Field label="Contact phone"><Input value={form.contact_phone} onChange={e=>set("contact_phone", e.target.value)} /></Field>
          <Field label="Contact email"><Input value={form.contact_email} onChange={e=>set("contact_email", e.target.value)} /></Field>
          <Field label="Coach/Club contact"><Input value={form.coach_contact} onChange={e=>set("coach_contact", e.target.value)} /></Field>

          <Field label="Contract status"><Input value={form.contract_status} onChange={e=>set("contract_status", e.target.value)} /></Field>
          <Field label="Contract until"><Input type="date" value={form.contract_until || ""} onChange={e=>set("contract_until", e.target.value)} /></Field>
          <Field label="Agency"><Input value={form.agency} onChange={e=>set("agency", e.target.value)} /></Field>

          <Field label="Appearances"><Input type="number" value={form.appearances} onChange={e=>set("appearances", e.target.value)} /></Field>
          <Field label="Minutes"><Input type="number" value={form.minutes} onChange={e=>set("minutes", e.target.value)} /></Field>
          <div />

          <Field label="Goals (last season)"><Input type="number" value={form.goals_last_season} onChange={e=>set("goals_last_season", e.target.value)} /></Field>
          <Field label="Assists (last season)"><Input type="number" value={form.assists_last_season} onChange={e=>set("assists_last_season", e.target.value)} /></Field>
          <Field label="Dribbles (last season)"><Input type="number" value={form.dribbles_last_season} onChange={e=>set("dribbles_last_season", e.target.value)} /></Field>

          <Field label="Injuries (last 3y)"><Input type="number" value={form.injuries_last_3y} onChange={e=>set("injuries_last_3y", e.target.value)} /></Field>
          <Field label="Transfermarkt URL"><Input value={form.transfermarkt_url} onChange={e=>set("transfermarkt_url", e.target.value)} /></Field>
          <div />
        </div>
      </Card>

      {/* Notes + Observations in one row: 2 columns */}
      <div className="grid md:grid-cols-2 gap-6 px-4 md:px-0">
        {/* LEFT: Sticky Notes */}
        <Card className="p-4 md:p-6 rounded-2xl space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold">Scout notes</h2>
            <span className="text-xs text-muted-foreground">Only visible to you</span>
          </div>

          {/* Sticky grid */}
          <div className="grid sm:grid-cols-2 xl:grid-cols-2 gap-4">
            {CATEGORIES.map((cat, idx) => {
              const s = catNotes[cat.key]
              const tilt = idx % 2 === 0 ? "-rotate-[0deg]" : "rotate-[0deg]"
              return (
                <div
                  key={cat.key}
                  className={`relative rounded-[18px] border bg-[#fffbe6] shadow-[0_8px_18px_rgba(0,0,0,0.08)] px-3 pt-2 pb-3 ${tilt}`}
                  style={{
                    backgroundImage: "linear-gradient(#fff4c2,#fffbe6 16px, #fffbe6)",
                  }}
                >
                  {/* top tape strip */}
                  <div className="absolute -top-1 left-1/2 -translate-x-1/2 h-2 w-16 bg-[#f7d879]/80 rounded-sm shadow" />
                  <div className="pr-7">
                    <div className="text-[13px] font-semibold leading-tight">{cat.label}</div>

                    {/* rating buttons 0..10 */}
                    <div className="mt-2 flex flex-wrap gap-1">
                      {Array.from({ length: 11 }, (_, n) => n).map(n => (
                        <button
                          key={n}
                          type="button"
                          onClick={() => setCat(cat.key, { rating: n })}
                          className={`h-7 min-w-[28px] px-2 rounded border text-xs transition
                            ${s?.rating === n
                              ? "bg-primary text-primary-foreground border-primary"
                              : "bg-white/70 hover:bg-white border-amber-300"
                            }`}
                          aria-label={`${n} out of 10`}
                        >
                          {n}
                        </button>
                      ))}
                    </div>

                    {/* comment */}
                    <Textarea
                      className="mt-2 h-[72px] resize-none bg-transparent border-amber-200 focus-visible:ring-amber-400"
                      placeholder="Short comment…"
                      value={s?.comment ?? ""}
                      onChange={(e) => setCat(cat.key, { comment: e.target.value })}
                    />
                  </div>

                  {/* actions: saving indicator + delete */}
                  <div className="absolute top-2 right-2 flex items-center gap-1">
                    {s?.saving ? (
                      <span className="text-[10px] text-amber-800 inline-flex items-center gap-1">
                        <Loader2 className="h-3 w-3 animate-spin" /> saving…
                      </span>
                    ) : s?.savedAt ? (
                      <span className="text-[10px] text-amber-800">saved</span>
                    ) : null}
                    <button
                      type="button"
                      onClick={() => deleteNote(cat.key)}
                      className="ml-1 h-7 w-7 grid place-items-center rounded-full hover:bg-amber-200/60"
                      title="Delete note"
                    >
                      <Trash2 className="h-4 w-4 text-amber-800" />
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        </Card>

        {/* RIGHT: Observations + Add-to-observation */}
        <ObservationsPanel
          supabase={supabase}
          userId={userId}
          playerId={player.id}
          observations={obs}
          onObservationsChange={setObs}
        />
      </div>
    </div>
  )
}

/* ---------- Observations panel (right column) ---------- */
function ObservationsPanel({
  supabase,
  userId,
  playerId,
  observations,
  onObservationsChange,
}: {
  supabase: ReturnType<typeof createClient>
  userId: string
  playerId: string
  observations: Observation[]
  onObservationsChange: (o: Observation[]) => void
}) {
  type SessionLite = { id: string; title: string | null; match_date: string }

  const [sessions, setSessions] = useState<SessionLite[]>([])
  const [chosenSession, setChosenSession] = useState<string>("")

  const [memberSessions, setMemberSessions] = useState<SessionLite[]>([])
  const [loadingMembers, setLoadingMembers] = useState<boolean>(true)
  const [adding, setAdding] = useState<boolean>(false)

  // 1) Load my sessions (for the select)
  useEffect(() => {
    ;(async () => {
      const { data, error } = await supabase
        .from("observation_sessions")
        .select("id, title, match_date")
        .eq("scout_id", userId)
        .order("match_date", { ascending: false })
      if (error) {
        console.error("Load sessions error:", error)
        toast.error(error.message || "Failed to load observation sessions")
        return
      }
      setSessions(data || [])
    })()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId])

  // 2) Load memberships safely (no join filters)
  useEffect(() => {
    if (!sessions.length) {
      setMemberSessions([])
      setLoadingMembers(false)
      return
    }
    loadMemberSessions()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sessions, playerId])

  async function loadMemberSessions() {
    setLoadingMembers(true)
    try {
      const sessionIds = sessions.map(s => s.id)
      if (!sessionIds.length) {
        setMemberSessions([])
        return
      }
      const { data, error } = await supabase
        .from("observation_players")
        .select("observation_id, player_id")
        .eq("player_id", playerId)
        .in("observation_id", sessionIds)

      if (error) {
        console.error("Load member sessions error:", error)
        toast.error(error.message || "Failed to load player memberships")
        return
      }

      const memberIds = new Set((data || []).map(r => r.observation_id as string))
      const rows: SessionLite[] = sessions.filter(s => memberIds.has(s.id))
      rows.sort((a, b) => (a.match_date < b.match_date ? 1 : -1)) // newest first
      setMemberSessions(rows)
    } catch (e: any) {
      console.error("Load member sessions error:", e)
      toast.error(e?.message || "Failed to load player memberships")
    } finally {
      setLoadingMembers(false)
    }
  }

  async function addToObservation() {
    if (!chosenSession) {
      toast.info("Choose an observation session first")
      return
    }
    if (memberSessions.some(ms => ms.id === chosenSession)) {
      toast.info("Player is already in this observation")
      return
    }

    setAdding(true)
    try {
      const { error } = await supabase.from("observation_players").insert({
        observation_id: chosenSession,
        player_id: playerId,
        minutes_watched: null,
        rating: null,
        notes: null,
      })
      if (error) throw error

      toast.success("Player added to observation")

      // refresh membership list
      await loadMemberSessions()

      // (optional) companion row in `observations`
      const sess = sessions.find(s => s.id === chosenSession)
      if (sess?.match_date) {
        await supabase.from("observations").insert({
          scout_id: userId,
          player_id: playerId,
          match_date: sess.match_date,
          competition: null,
          opponent: null,
          minutes_watched: null,
          notes: null,
        }).catch(() => {})
        const { data } = await supabase
          .from("observations")
          .select("id, match_date, competition, opponent, minutes_watched, notes, created_at")
          .eq("player_id", playerId).eq("scout_id", userId)
          .order("match_date", { ascending: false })
        onObservationsChange(data || [])
      }
    } catch (e: any) {
      console.error("Add to observation error:", e)
      toast.error(e?.message || "Could not add player to observation")
    } finally {
      setAdding(false)
    }
  }

  return (
    <Card className="p-4 md:p-6 rounded-2xl space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <h2 className="text-lg font-semibold">Your observations</h2>
        <div className="flex items-center gap-2">
          <Select value={chosenSession} onValueChange={setChosenSession} disabled={adding}>
            <SelectTrigger className="h-9 w-[260px]">
              <SelectValue placeholder="Choose observation session…" />
            </SelectTrigger>
            <SelectContent>
              {sessions.length === 0 ? (
                <div className="px-2 py-1.5 text-xs text-muted-foreground">No sessions found</div>
              ) : (
                sessions.map(s => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.match_date} {s.title ? `· ${s.title}` : ""}
                  </SelectItem>
                ))
              )}
            </SelectContent>
          </Select>
          <Button size="sm" onClick={addToObservation} disabled={!chosenSession || adding}>
            {adding ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Adding…</> : "Add player"}
          </Button>
        </div>
      </div>

      {/* Membership summary (from observation_players) */}
      <div className="space-y-2">
        <div className="text-sm font-medium">This player is in:</div>
        {loadingMembers ? (
          <div className="text-sm text-muted-foreground">Loading…</div>
        ) : memberSessions.length === 0 ? (
          <div className="text-sm text-muted-foreground">No observations yet.</div>
        ) : (
          <div className="grid gap-2">
            {memberSessions.map(ms => (
              <div key={ms.id} className="rounded-xl border p-3 flex items-center justify-between gap-3">
                <div>
                  <div className="text-sm font-medium">
                    {ms.match_date}{ms.title ? ` · ${ms.title}` : ""}
                  </div>
                </div>
                <Button asChild size="sm" variant="outline">
                  <Link href={`/scout/observations/${ms.id}`}>Check observation</Link>
                </Button>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Existing observation records (from `observations`) */}
      {observations.length > 0 && (
        <>
          <Separator />
          <div className="space-y-2">
            <div className="text-sm font-medium">Observation records</div>
            <div className="grid gap-3">
              {observations.map(o => (
                <div key={o.id} className="rounded-xl border p-3">
                  <div className="text-sm font-medium">
                    {o.match_date}{o.opponent ? ` · vs ${o.opponent}` : ""}
                  </div>
                  <div className="text-xs text-muted-foreground">
                    {o.competition || "—"} {o.minutes_watched ? `· ${o.minutes_watched}’` : ""}
                  </div>
                  {o.notes && <p className="mt-2 text-sm">{o.notes}</p>}
                </div>
              ))}
            </div>
          </div>
        </>
      )}
    </Card>
  )
}



/* ---------- tiny UI helpers ---------- */
function Field({ label, icon, children }: { label: string; icon?: React.ReactNode; children: React.ReactNode }) {
  return (
    <div className="grid gap-1.5">
      <Label className="flex items-center gap-2">{icon}{label}</Label>
      {children}
    </div>
  )
}
function ToggleField({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v:boolean)=>void }) {
  return (
    <div className="flex items-center justify-between border rounded-lg p-3">
      <div><Label>{label}</Label></div>
      <Switch checked={checked} onCheckedChange={onChange} />
    </div>
  )
}
