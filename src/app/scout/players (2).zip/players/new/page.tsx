// src/app/scout/players/new/page.tsx
"use client"

import { useEffect, useMemo, useRef, useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { createClient } from "@/lib/supabase/browser"
import { toast } from "sonner"


import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectTrigger, SelectValue, SelectContent, SelectItem } from "@/components/ui/select"
import { Switch } from "@/components/ui/switch"
import { Separator } from "@/components/ui/separator"

import {
  Calendar, CheckCircle2, Image as ImageIcon, Link2, Upload, XCircle,
  ShieldPlus, Plus, X, Globe2, Footprints, Phone, Mail, UserRound, Building2, Flag,
  Loader2, ExternalLink,
} from "lucide-react"

const POSITIONS = ["GK","RB","CB","LB","RWB","LWB","DM","CM","AM","RW","LW","CF","ST"] as const
const FEET = ["left", "right", "both"] as const

type DupCheck = {
  inMyPlayers: boolean
  existingEntry: boolean
  matchedPlayerName?: string
  matchedPlayerId?: string
}

function TagInput({
  label, placeholder, values, setValues, description,
}: {
  label: string
  placeholder?: string
  values: string[]
  setValues: (arr: string[]) => void
  description?: string
}) {
  const [val, setVal] = useState("")
  const add = () => {
    const v = val.trim()
    if (!v) return
    if (!values.includes(v)) setValues([...values, v])
    setVal("")
  }
  const remove = (tag: string) => setValues(values.filter(t => t !== tag))
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      <div className="flex items-center gap-2">
        <Input
          value={val}
          onChange={e => setVal(e.target.value)}
          placeholder={placeholder}
          onKeyDown={e => { if (e.key === "Enter") { e.preventDefault(); add() } }}
        />
        <Button type="button" variant="secondary" onClick={add}><Plus className="h-4 w-4" /></Button>
      </div>
      {description && <p className="text-xs text-muted-foreground">{description}</p>}
      {!!values.length && (
        <div className="flex flex-wrap gap-2">
          {values.map(tag => (
            <Badge key={tag} variant="secondary" className="gap-1">
              {tag}
              <button type="button" aria-label="remove" onClick={() => remove(tag)}>
                <X className="h-3 w-3 ml-1" />
              </button>
            </Badge>
          ))}
        </div>
      )}
    </div>
  )
}

export default function NewPlayerPage() {
  const supabase = createClient()
  const router = useRouter()
  const [isPending, start] = useTransition()

  // required
  const [firstName, setFirstName] = useState("")
  const [lastName, setLastName] = useState("")

  // optional - identity
  const [dob, setDob] = useState("")
  const [height, setHeight] = useState<string>("")
  const [weight, setWeight] = useState<string>("")
  const [countryOfBirth, setCountryOfBirth] = useState("")
  const [hasEU, setHasEU] = useState(false)

  // club
  const [club, setClub] = useState("")
  const [clubCountry, setClubCountry] = useState("")
  const [clubTier, setClubTier] = useState<string>("")

  // positions
  const [mainPos, setMainPos] = useState("")
  const [altPositions, setAltPositions] = useState<string[]>([])
  const [dominantFoot, setDominantFoot] = useState<string>("")

  // language + contacts
  const [englishSpeaks, setEnglishSpeaks] = useState(false)
  const [englishLevel, setEnglishLevel] = useState("")
  const [phoneNo, setPhoneNo] = useState("")
  const [email, setEmail] = useState("")
  const [facebookUrl, setFacebookUrl] = useState("")
  const [instagramUrl, setInstagramUrl] = useState("")

  // links
  const [tm, setTm] = useState("")
  const [videoUrls, setVideoUrls] = useState<string[]>([])
  const [tmId, setTmId] = useState<string | null>(null)

  // contract/agency/coach
  const [contractStatus, setContractStatus] = useState("")
  const [contractUntil, setContractUntil] = useState("")
  const [agency, setAgency] = useState("")
  const [coachContact, setCoachContact] = useState("")

  // career stats
  const [clubsLast5, setClubsLast5] = useState<string>("")
  const [leaguesJson, setLeaguesJson] = useState("") // free json or CSV "PL-2, DE-3"
  const [appearances, setAppearances] = useState<string>("")
  const [minutes, setMinutes] = useState<string>("")
  const [natCaps, setNatCaps] = useState(false)
  const [natMinutes, setNatMinutes] = useState<string>("")
  const [goals, setGoals] = useState<string>("")
  const [assists, setAssists] = useState<string>("")
  const [dribbles, setDribbles] = useState<string>("")
  const [injuries3y, setInjuries3y] = useState<string>("")

  // opinion
  const [opinion, setOpinion] = useState("")

  // image
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState<string | null>(null)

  // duplicate state
  const [dup, setDup] = useState<DupCheck | null>(null)
  const [checkingDup, setCheckingDup] = useState(false)

  // TM modal/search state
  const [tmQuerying, setTmQuerying] = useState(false) // spinner in last name
  const [tmCandidates, setTmCandidates] = useState<any[]>([])
  const [tmModalOpen, setTmModalOpen] = useState(false)
  const [tmChosen, setTmChosen] = useState<any | null>(null)
  

  // derived
  const fullName = useMemo(() => `${firstName.trim()} ${lastName.trim()}`.trim(), [firstName, lastName])

  const tmValid = useMemo(() => {
    if (!tm) return true
    try { return new URL(tm).hostname.includes("transfermarkt") } catch { return false }
  }, [tm])

  const emailValid = useMemo(() => {
    if (!email.trim()) return true
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())
  }, [email])

  // DO NOT block Save on duplicates anymore
const isSaveDisabled = useMemo(() => {
  if (!firstName.trim() || !lastName.trim()) return true
  if (!tmValid) return true
  if (!emailValid) return true
  return isPending
}, [firstName, lastName, tmValid, emailValid, isPending])

  // file handler
  const onFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0] || null
    setFile(f)
    setPreview(f ? URL.createObjectURL(f) : null)
  }

  // upload to Supabase Storage (players bucket)
  const uploadImage = async (): Promise<{ url?: string; path?: string; error?: string }> => {
    if (!file) return {}
    const { data: { user } } = await supabase.auth.getUser()
    if (!user) return { error: "Not authenticated" }

    const ext = file.name.split(".").pop()?.toLowerCase() || "jpg"
    const path = `${user.id}/entries/${crypto.randomUUID()}.${ext}`

    const { error: upErr } = await supabase.storage.from("players").upload(path, file, {
      upsert: false,
      cacheControl: "3600",
    })
    if (upErr) return { error: upErr.message }

    const { data } = supabase.storage.from("players").getPublicUrl(path)
    return { url: data.publicUrl, path }
  }

// Accent/case-insensitive comparison
function normName(s: string) {
  return s.normalize("NFD").replace(/\p{Diacritic}/gu, "").toLowerCase().trim()
}


  // ===== Transfermarkt search helpers =====
  function computeMissingFields() {
    const wanted: Record<string, string> = {
      date_of_birth: dob,
      height_cm: height,
      weight_kg: weight,
      country_of_birth: countryOfBirth,
      current_club_name: club,
      current_club_country: clubCountry,
      current_club_tier: clubTier,
      main_position: mainPos,
      dominant_foot: dominantFoot,
      transfermarkt_url: tm,
    }
    return Object.entries(wanted)
      .filter(([, v]) => !String(v ?? "").trim())
      .map(([k]) => k)
  }

  function prefillFromTm(candidate: any) {
    setTmId(candidate?.tm_id ?? null)
    if (candidate?.profile_url) setTm(candidate.profile_url)
    if (candidate?.date_of_birth) setDob(candidate.date_of_birth)
    if (candidate?.height_cm) setHeight(String(candidate.height_cm))
    if (candidate?.position_main) setMainPos(candidate.position_main)
    if (candidate?.dominant_foot) setDominantFoot(candidate.dominant_foot)
    if (candidate?.current_club_name) setClub(candidate.current_club_name)
    // name stays as the user typed (first/last)
  }

async function searchTransfermarktBySurname(surname: string, first?: string) {
  setTmQuerying(true)
  try {
    const url = `/api/tm/search?q=${encodeURIComponent(surname)}${first ? `&first=${encodeURIComponent(first)}` : ""}`
    const res = await fetch(url, { cache: "no-store" })
    const j = await res.json()
    if (!res.ok) throw new Error(j?.error || "TM search failed")

    const items = j?.items || []
    setTmCandidates(items)

    const fullTyped = [first, surname].filter(Boolean).join(" ")
    const exactMatches = items.filter((p: any) => normName(p.name) === normName(fullTyped))

    if (exactMatches.length === 1) {
      const m = exactMatches[0]
      // Clear modal (we'll offer actions via toast instead)
      setTmModalOpen(false)
      setTmChosen(m)

      toast.success("Found on Transfermarkt", {
        description: `${m.name}${m.date_of_birth ? ` · DoB ${m.date_of_birth}` : ""}${m.current_club_name ? ` · ${m.current_club_name}` : ""}`,
        action: {
          label: "Prefill",
          onClick: () => {
            prefillFromTm(m)
            toast.success("Prefilled from Transfermarkt", { description: m.name })
          },
        },
        duration: 7000,
      })
    } else if (items.length > 0) {
      // Informative toast + let the user open the picker
      toast.message("Transfermarkt: candidates found", {
        description: `${items[0].name}${items[0].date_of_birth ? ` · DoB ${items[0].date_of_birth}` : ""}${items[0].current_club_name ? ` · ${items[0].current_club_name}` : ""}`,
        action: {
          label: "Open list",
          onClick: () => setTmModalOpen(true),
        },
        duration: 6000,
      })
      setTmModalOpen(true)
    } else {
      // optional: stay quiet or show a soft info
      // toast.info("No TM matches yet. You can continue manually.")
      setTmModalOpen(false)
      setTmChosen(null)
    }
  } catch (e: any) {
    toast.error(e?.message || "Transfermarkt search unavailable – continue manually.")
    setTmModalOpen(false)
    setTmCandidates([])
    setTmChosen(null)
  } finally {
    setTmQuerying(false)
  }
}



 

  // ===== Duplicate check (debounced) — by name (+ DoB if provided) =====
  const prevDupRef = useRef<DupCheck | null>(null)

useEffect(() => {
  const fn = firstName.trim()
  const ln = lastName.trim()

  if (fn.length < 1 || ln.length < 2) {      // <— require both
    setTmQuerying(false)
    setTmModalOpen(false)
    setTmCandidates([])
    setTmChosen(null)
    return
  }

  setTmQuerying(true)
  const t = window.setTimeout(() => {
    searchTransfermarktBySurname(ln, fn)
  }, 450)
  return () => window.clearTimeout(t)
}, [firstName, lastName])



  // ===== Submit =====
  const submit = () => {
    start(async () => {
      if (!firstName.trim() || !lastName.trim()) {
        toast.error("First name and Last name are required.")
        return
      }
      if (!tmValid) { toast.error("Transfermarkt link looks invalid."); return }
      if (!emailValid) { toast.error("E-mail looks invalid."); return }

      // Note: we DO NOT block on duplicates anymore — we only notified via toast.

      // upload image if present
      let image_url: string | undefined
      let image_path: string | undefined
      if (file) {
        const up = await uploadImage()
        if (up.error) { toast.error(`Upload failed: ${up.error}`); return }
        image_url = up.url
        image_path = up.path
      }

      const payload = {
        // required
        first_name: firstName.trim(),
        last_name: lastName.trim(),

        // identity
        full_name: fullName,
        date_of_birth: dob || null,
        height_cm: height ? Number(height) : null,
        weight_kg: weight ? Number(weight) : null,
        country_of_birth: countryOfBirth || null,
        has_eu_passport: hasEU,

        // club
        current_club_name: club || null,
        current_club_country: clubCountry || null,
        current_club_tier: clubTier ? Number(clubTier) : null,

        // positions
        main_position: mainPos || null,
        alt_positions: altPositions,
        dominant_foot: dominantFoot || null,

        // language & contacts
        english_speaks: englishSpeaks,
        english_level: englishLevel || null,
        contact_phone: phoneNo || null,
        contact_email: email || null,
        facebook_url: facebookUrl || null,
        instagram_url: instagramUrl || null,

        // links
        transfermarkt_url: tm || null,
        transfermarkt_player_id: tmId,
        video_urls: videoUrls,

        // contract / agency / coach
        contract_status: contractStatus || null,
        contract_until: contractUntil || null,
        agency: agency || null,
        coach_contact: coachContact || null,

        // career
        clubs_last5: clubsLast5 ? Number(clubsLast5) : null,
        leagues: leaguesJson ? leaguesJson : null,
        appearances: appearances ? Number(appearances) : null,
        minutes: minutes ? Number(minutes) : null,
        national_team_caps: natCaps,
        national_team_minutes: natMinutes ? Number(natMinutes) : null,
        goals_last_season: goals ? Number(goals) : null,
        assists_last_season: assists ? Number(assists) : null,
        dribbles_last_season: dribbles ? Number(dribbles) : null,
        injuries_last_3y: injuries3y ? Number(injuries3y) : null,

        // extras
        opinion: opinion || null,

        // image
        image_url,
        image_path,
      }

      const res = await fetch("/api/scout/players", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })

      if (!res.ok) {
        const body = await res.json().catch(() => ({}))
        toast.error(body.error || "Failed to save.")
        if (res.status === 401) router.push("/login?redirect_to=/scout/players/new")
        return
      }

      toast.success("Player submitted", {
        description: fullName,
        action: {
          label: "Open list",
          onClick: () => router.push("/scout/players"),
        },
      })
      router.push("/scout/players")
    })
  }

  return (
    <div className="space-y-6 w-full p-4 md:p-8">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-semibold">Add Player</h1>
        <div className="hidden md:flex items-center gap-2 text-xs text-muted-foreground">
          <CheckCircle2 className="h-4 w-4" />
          Required: First name, Last name
        </div>
      </div>

      <Card className="p-6 space-y-6 rounded-2xl w-full">
        {/* Photo */}
        <div className="grid gap-2">
          <Label className="flex items-center gap-2">
            <ImageIcon className="h-4 w-4" /> Photo
          </Label>
          <div className="flex items-center gap-3">
            <Input type="file" accept="image/*" onChange={onFileChange} />
            {preview ? (
              <img src={preview} alt="preview" className="h-20 w-20 rounded-md object-cover border" />
            ) : (
              <div className="h-20 w-20 rounded-md border grid place-items-center text-muted-foreground text-xs">
                Preview
              </div>
            )}
          </div>
          <p className="text-xs text-muted-foreground">Square images (1:1) look best. Max ~5MB recommended.</p>
        </div>

        {/* Identity */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><UserRound className="h-4 w-4" /> First name *</Label>
            <Input value={firstName} onChange={e => setFirstName(e.target.value)} placeholder="Robert" />
          </div>
          <div className="grid gap-2">
            <Label>Last name *</Label>
            {/* Input with inline spinner */}
            <div className="relative">
              <Input
                value={lastName}
                onChange={e => setLastName(e.target.value)}
                placeholder="Lewandowski"
                className={tmQuerying ? "pr-8" : undefined}
              />
              {tmQuerying && (
                <Loader2 className="absolute right-2 top-1/2 -translate-y-1/2 h-4 w-4 animate-spin text-muted-foreground" />
              )}
            </div>

{!tmQuerying && tmCandidates.length > 0 && (
  <div className="text-xs text-muted-foreground">
    Found {tmCandidates.length} result{tmCandidates.length > 1 ? "s" : ""} on Transfermarkt.{" "}
    <button className="underline" type="button" onClick={() => setTmModalOpen(true)}>
      Review
    </button>
  </div>
)}

          </div>
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Calendar className="h-4 w-4" /> Date of birth</Label>
            <Input type="date" value={dob} onChange={e => setDob(e.target.value)} />
          </div>

          <div className="grid gap-2">
            <Label>Height (cm)</Label>
            <Input type="number" inputMode="numeric" value={height} onChange={e => setHeight(e.target.value)} placeholder="183" />
          </div>
          <div className="grid gap-2">
            <Label>Weight (kg)</Label>
            <Input type="number" inputMode="numeric" value={weight} onChange={e => setWeight(e.target.value)} placeholder="78" />
          </div>
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Flag className="h-4 w-4" /> Country of birth</Label>
            <Input value={countryOfBirth} onChange={e => setCountryOfBirth(e.target.value)} placeholder="Poland" />
          </div>
        </div>

        {/* Citizenship & English */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="flex items-center justify-between border rounded-lg p-3">
            <div>
              <Label>EU Passport</Label>
              <p className="text-xs text-muted-foreground">Has EU citizenship?</p>
            </div>
            <Switch checked={hasEU} onCheckedChange={setHasEU} />
          </div>
          <div className="flex items-center justify-between border rounded-lg p-3">
            <div>
              <Label>Speaks English</Label>
              <p className="text-xs text-muted-foreground">Simple yes/no</p>
            </div>
            <Switch checked={englishSpeaks} onCheckedChange={setEnglishSpeaks} />
          </div>
          <div className="grid gap-2">
            <Label>English level</Label>
            <Input value={englishLevel} onChange={e => setEnglishLevel(e.target.value)} placeholder="A2 / B1 / B2 / C1" />
          </div>
        </div>

        <Separator />

        {/* Club & League */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Building2 className="h-4 w-4" /> Current club</Label>
            <Input value={club} onChange={e => setClub(e.target.value)} placeholder="Wisła Kraków" />
          </div>
          <div className="grid gap-2">
            <Label>Current club country</Label>
            <Input value={clubCountry} onChange={e => setClubCountry(e.target.value)} placeholder="Poland" />
          </div>
          <div className="grid gap-2">
            <Label>League level</Label>
            <Input type="number" inputMode="numeric" value={clubTier} onChange={e => setClubTier(e.target.value)} placeholder="1 (top), 2, 3..." />
          </div>
        </div>

        {/* Positions */}
        <div className="grid md:grid-cols-2 gap-6">
          <div className="grid gap-2">
            <Label>Main position</Label>
            <div className="flex flex-wrap gap-2">
              <Input
                value={mainPos}
                onChange={e => setMainPos(e.target.value)}
                placeholder="e.g., CF, CM, RW"
                className="max-w-[220px]"
              />
              <div className="flex flex-wrap gap-1">
                {POSITIONS.map(p => (
                  <Badge
                    key={p}
                    variant={mainPos === p ? "default" : "outline"}
                    className="cursor-pointer"
                    onClick={() => setMainPos(p)}
                  >
                    {p}
                  </Badge>
                ))}
              </div>
            </div>
          </div>

          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Footprints className="h-4 w-4" /> Dominant foot</Label>
            <Select value={dominantFoot} onValueChange={setDominantFoot}>
              <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>
                {FEET.map(f => <SelectItem key={f} value={f}>{f}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
        </div>

        <TagInput
          label="Alternative positions"
          placeholder="Add position code, e.g. RW"
          values={altPositions}
          setValues={setAltPositions}
        />

        <Separator />

        {/* Contacts */}
        <div className="grid md:grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Phone className="h-4 w-4" /> Contact phone</Label>
            <Input value={phoneNo} onChange={e => setPhoneNo(e.target.value)} placeholder="+48 600 000 000" />
          </div>
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Mail className="h-4 w-4" /> Contact e-mail</Label>
            <Input value={email} onChange={e => setEmail(e.target.value)} placeholder="player@mail.com" />
            {!emailValid && <p className="text-xs text-red-600">E-mail looks invalid.</p>}
          </div>
          <div className="grid gap-2">
            <Label>Facebook URL</Label>
            <Input value={facebookUrl} onChange={e => setFacebookUrl(e.target.value)} placeholder="https://facebook.com/..." />
          </div>
          <div className="grid gap-2">
            <Label>Instagram URL</Label>
            <Input value={instagramUrl} onChange={e => setInstagramUrl(e.target.value)} placeholder="https://instagram.com/..." />
          </div>
        </div>

        {/* Links */}
        <div className="grid md:grid-cols-2 gap-4">
          <div className="grid gap-2">
            <Label className="flex items-center gap-2"><Link2 className="h-4 w-4" /> Transfermarkt link</Label>
            <Input
              value={tm}
              onChange={e => setTm(e.target.value)}
              placeholder="https://www.transfermarkt.com/..."
            />
            {!tmValid && (
              <div className="text-xs text-red-600 flex items-center gap-2">
                <XCircle className="h-4 w-4" /> This doesn’t look like a valid Transfermarkt URL.
              </div>
            )}
            <p className="text-xs text-muted-foreground">Optional, but helps us sync details quickly.</p>
          </div>

          <TagInput
            label="Video links"
            placeholder="Paste video URL and press Enter"
            values={videoUrls}
            setValues={setVideoUrls}
            description="You can add multiple video URLs."
          />
        </div>

        <Separator />

        {/* Contract / Agency / Coach */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="grid gap-2">
            <Label>Contract status</Label>
            <Input value={contractStatus} onChange={e => setContractStatus(e.target.value)} placeholder="e.g. active / free agent" />
          </div>
          <div className="grid gap-2">
            <Label>Contract until</Label>
            <Input type="date" value={contractUntil} onChange={e => setContractUntil(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Agency</Label>
            <Input value={agency} onChange={e => setAgency(e.target.value)} placeholder="Agency name" />
          </div>
          <div className="md:col-span-3 grid gap-2">
            <Label>Coach/Club contact</Label>
            <Input value={coachContact} onChange={e => setCoachContact(e.target.value)} placeholder="Name, role, phone/email" />
          </div>
        </div>

        <Separator />

        {/* Career stats */}
        <div className="grid md:grid-cols-3 gap-4">
          <div className="grid gap-2">
            <Label>Clubs last 5 years</Label>
            <Input type="number" inputMode="numeric" value={clubsLast5} onChange={e => setClubsLast5(e.target.value)} placeholder="e.g. 3" />
          </div>
          <div className="md:col-span-2 grid gap-2">
            <Label className="flex items-center gap-2"><Globe2 className="h-4 w-4" /> Leagues played in (country + level)</Label>
            <Textarea
              value={leaguesJson}
              onChange={e => setLeaguesJson(e.target.value)}
              placeholder='Free text or JSON, e.g. [{"country":"PL","level":2}]'
            />
          </div>

          <div className="grid gap-2">
            <Label>Matches</Label>
            <Input type="number" inputMode="numeric" value={appearances} onChange={e => setAppearances(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Minutes</Label>
            <Input type="number" inputMode="numeric" value={minutes} onChange={e => setMinutes(e.target.value)} />
          </div>
          <div className="flex items-center justify-between border rounded-lg p-3">
            <div>
              <Label>Played for National Team</Label>
              <p className="text-xs text-muted-foreground">Senior or youth</p>
            </div>
            <Switch checked={natCaps} onCheckedChange={setNatCaps} />
          </div>
          <div className="grid gap-2">
            <Label>National team minutes</Label>
            <Input type="number" inputMode="numeric" value={natMinutes} onChange={e => setNatMinutes(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Goals last season</Label>
            <Input type="number" inputMode="numeric" value={goals} onChange={e => setGoals(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Assists last season</Label>
            <Input type="number" inputMode="numeric" value={assists} onChange={e => setAssists(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Dribbles last season</Label>
            <Input type="number" inputMode="numeric" value={dribbles} onChange={e => setDribbles(e.target.value)} />
          </div>
          <div className="grid gap-2">
            <Label>Injuries in last 3 years</Label>
            <Input type="number" inputMode="numeric" value={injuries3y} onChange={e => setInjuries3y(e.target.value)} />
          </div>
        </div>

        {/* Opinion */}
        <div className="grid gap-2">
          <Label>Opinion</Label>
          <Textarea value={opinion} onChange={e => setOpinion(e.target.value)} placeholder="Short summary or notes" />
        </div>

        {/* No inline duplicate banners anymore */}

        {/* Actions */}
        <div className="flex flex-wrap gap-2">
          <Button onClick={submit} disabled={isSaveDisabled}>
            {isPending ? (
              <span className="inline-flex items-center gap-2">
                <Upload className="h-4 w-4 animate-pulse" /> Saving…
              </span>
            ) : ("Save")}
          </Button>
          <Button type="button" variant="outline" onClick={() => router.push("/scout/players")}>Cancel</Button>
        </div>

        {/* Help footer */}
        <div className="text-xs text-muted-foreground">
          Tip: If the player already exists, open their card in Discover and click <b>Add to My Players</b>.
        </div>
      </Card>

      {/* ===== Transfermarkt Modal ===== */}
      {tmModalOpen && (
        <div className="fixed inset-0 z-50">
          {/* backdrop */}
          <div className="absolute inset-0 bg-black/50" onClick={() => setTmModalOpen(false)} />
          {/* modal */}
          <div className="absolute inset-x-0 top-10 mx-auto w-[min(960px,92vw)] rounded-xl bg-background border shadow-xl p-4 md:p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-xl font-semibold">Found on Transfermarkt</h3>
              <Button variant="ghost" onClick={() => setTmModalOpen(false)}>Close</Button>
            </div>

            {tmQuerying ? (
              <div className="text-sm text-muted-foreground">Searching…</div>
            ) : tmCandidates.length === 0 ? (
              <div className="text-sm">No players found for that name.</div>
            ) : (
              <>
                <div className="grid gap-3 max-h-[50vh] overflow-auto pr-1">
                  {tmCandidates.map((c) => (
                    <button
                      key={c.tm_id}
                      onClick={() => setTmChosen(c)}
                      className={`text-left border rounded-lg p-3 hover:bg-accent transition ${
                        tmChosen?.tm_id === c.tm_id ? "ring-2 ring-primary" : ""
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        {c.image_url ? (
                          <img src={c.image_url} alt="" className="h-12 w-12 rounded object-cover border" />
                        ) : (
                          <div className="h-12 w-12 rounded bg-muted grid place-items-center text-xs text-muted-foreground">No img</div>
                        )}
                        <div className="min-w-0">
                          <div className="font-medium truncate">{c.name}</div>
                          <div className="text-xs text-muted-foreground">
                            {c.date_of_birth ? `DoB: ${c.date_of_birth} · ` : ""}
                            {c.position_main ? `Pos: ${c.position_main} · ` : ""}
                            {c.current_club_name ? `Club: ${c.current_club_name}` : ""}
                          </div>
                          {c.profile_url && (
                            <div className="text-xs inline-flex items-center gap-1 text-muted-foreground">
                              <a className="underline" href={c.profile_url} target="_blank" rel="noreferrer">Open TM profile</a>
                              <ExternalLink className="h-3 w-3" />
                            </div>
                          )}
                        </div>
                      </div>
                    </button>
                  ))}
                </div>

                {/* Missing fields */}
                {tmChosen && (
                  <div className="rounded-lg border p-3">
                    <div className="text-sm font-medium mb-1">Missing fields (in your form)</div>
                    <div className="flex flex-wrap gap-2 text-xs">
                      {computeMissingFields().map((k) => (
                        <span key={k} className="px-2 py-1 rounded bg-amber-100 text-amber-900 border border-amber-300">{k}</span>
                      ))}
                      {computeMissingFields().length === 0 && (
                        <span className="text-muted-foreground">No obvious gaps. You can still adjust after prefilling.</span>
                      )}
                    </div>
                  </div>
                )}

                <div className="flex items-center justify-end gap-2 pt-2">
                  <Button variant="outline" onClick={() => setTmModalOpen(false)}>Cancel</Button>
                  <Button
                    disabled={!tmChosen}
                    onClick={() => {
                      if (tmChosen) prefillFromTm(tmChosen)
                      setTmModalOpen(false)
                      toast.success("Prefilled from Transfermarkt", {
                        description: `${tmChosen.name}${tmChosen.date_of_birth ? ` · ${tmChosen.date_of_birth}` : ""}`,
                      })
                    }}
                  >
                    Use this profile
                  </Button>
                </div>
              </>
            )}
          </div>
        </div>
      )}
    </div>
  )
}
